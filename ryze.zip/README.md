
```
apt update && apt upgrade -y
```
```
git clone https://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@github.com/danyapreynz/Celestial
```
```
cd Celestial && screen -S Celestial
```
```
bash installnode.sh && apt install python3.10-venv
```
```
python3 -m venv Celestial && source Celestial/bin/activate
```
```
pip3 install -r requirements.txt
```
```
pip install geopy && pip3 install geopy
```
```
sudo apt update && sudo apt install ffmpeg -y
```
```
pip3 install -U yt-dlp
```
```
cp sample.env .env && nano .env
```
```
python3 -m PyroUbot
```
```
---------- Menghidupan jika ubot mati -------------
```
```
cd Celestial && screen -S Celestial
```
```
python3 -m venv venv && source venv/bin/activate
```
```
screen -S Celestial
```
```
python3 -m Pyroubot
```