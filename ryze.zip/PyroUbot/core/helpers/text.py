from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from PyroUbot import OWNER_ID, bot, ubot, get_expired_date
from platform import python_version
from pyrogram import __version__
class MSG:     
    def EXP_MSG_UBOT(X):
        return f"""<b>❏ ᴘᴇᴍʙᴇʀɪᴛᴀʜᴜᴀɴ</b>
<b>╭〄➠ ᴀᴄᴄᴏᴜɴᴛ :</b> <a href=tg://user?id={X.me.id}>{X.me.first_name} {X.me.last_name or ''}</a>
<b>├〄➠ ᴜsᴇʀ ɪᴅ:</b> <code>{X.me.id}</code>
<b>╰〄➠ ᴍᴀsᴀ ᴀᴋᴛɪꜰ ᴛᴇʟᴀʜ ʜᴀʙɪs</b>"""
    def START(message):
        return f"""
<b>halo 👋🏻  <a href=tg://user?id={message.from_user.id}>{message.from_user.first_name} {message.from_user.last_name or ''}</a></b>❕
<blockquote><b>📚 {bot.me.mention} adalah bot multi client yang dapat membuat userbot dengan sangat mudah.</b>

<b>🆘 kebijakan & ketentuan:</b>
<b>  - userbot no watermark / anti wm</b>
<b>  - akun keban? tenang ! ada garansi </b>
<b>  - banyak tools/fitur berguna lainnya</b>
<b>  - harap anda membaca resiko & syarat</b>
<b>  - panduan lengkap bisa langsung chat developer</b>
<b>  - membeli = anda setuju dengan segala resiko</b>

<b>✨ bot ini dikembangkan oleh: @Ryzesxx, bot ini di rancang untuk memudahkan pengguna telegram untuk mengirim pesan group&user telegram dengan instant, dan memiliki banyak fitur yang berguna lainnya.</b></blockquote>
<b>👉 silahkan pilih salah satu tombol di bawah ini</b>
<b>- jika ada kendala silahkan hubungi developer.</b>"""
    def TEXT_PAYMENT(harga, total, bulan):
        return f"""
<b>💎 Harga Akses userbot:</b>
<b>• Rp. 10.000 = 1 Bulan</b>
<b>• Rp. 20.000 = 2 Bulan</b>
<b>• Rp. 30.000 = 3 Bulan</b>

<b>‼️ Dukungan&Penjelasan:</b>
<b>untuk melihat rules dan penjelasan userbot silahkan ketik /dukungan </b>

<b>jika ingin melanjutkan pembayaran silahkan klik tombol di bawah ini.</b>"""

    async def UBOT(count):
        return f"""
╭〄➠ <b>ᴜsᴇʀ ᴋᴇ </b> <code>{int(count) + 1}/{len(ubot._ubot)}</code>
├〄➠ <b>ᴀᴄᴄᴏᴜɴᴛ </b> <a href=tg://user?id={ubot._ubot[int(count)].me.id}>{ubot._ubot[int(count)].me.first_name} {ubot._ubot[int(count)].me.last_name or ''}</a> 
╰〄➠ <b>ᴜsᴇʀ ɪᴅ </b> <code>{ubot._ubot[int(count)].me.id}</code>
"""

    def POLICY():
        return """ᴊɪᴋᴀ ᴀᴅᴀ ᴋᴇɴᴅᴀʟᴀ sɪʟᴀʜᴋᴀɴ ʜᴜʙᴜɴɢɪ  <a href=tg://openmessage?user_id={OWNER_ID}>Ryzesxx</a> """
