import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "250"))

DEVS = list(map(int, os.getenv("DEVS", "7851970809").split()))

API_ID = int(os.getenv("API_ID", "9701491"))

API_HASH = os.getenv("API_HASH", "58a8de6d98c5e4952ab7c616ba695847")

BOT_TOKEN = os.getenv("BOT_TOKEN", "7707618457:AAEPjQbzEhmSJ0UCNIppe06yoVPL-0jek1g")

OWNER_ID = int(os.getenv("OWNER_ID", "7851970809"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002295820499").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://Celestial:REYHAN1212@celestial.4plygu2.mongodb.net/?appName=Celestial")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT"))
