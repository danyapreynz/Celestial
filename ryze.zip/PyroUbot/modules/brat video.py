__MODULE__ = "brat-video"
__HELP__ = """📖 <u><b>Folder Module Brat Video</b></u>

<blockquote><b>📚 perintah: .bratvid [ᴛᴇxᴛ]</b>
<b>📝 penjelasan: untuk membuat text brat berjalan</b></blockquote>"""