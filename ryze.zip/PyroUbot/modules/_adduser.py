import asyncio
import importlib
from datetime import datetime
from dateutil.relativedelta import relativedelta
from pytz import timezone
from pyrogram.enums import SentCodeType
from pyrogram.errors import *
from pyrogram.types import *
from pyrogram.raw import functions

from PyroUbot import *

@PY.CALLBACK("makluMATIJIR")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
         [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"temulawak")],
         ]
        return await callback_query.edit_message_text(
            f"""<b>💳 DANA: 08812583388</b>
<b>👤 ATAS NAMA: SAENAH</b>
<b>💳 GOPAY: 08812583388 💸</b>
<b>👤 ATAS NAMA: -- </b>
<b>💳 OVO: GAPUNYA 🤓</b>
<b>👤 ATAS NAMA: - - -</b>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )

@PY.CALLBACK("menulahWAK")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [
            InlineKeyboardButton("「 📝 Harga Seles 」", callback_data=f"SELESPROMO"),
            InlineKeyboardButton("「 📝 Harga Admin 」", callback_data=f"ADMINPROMO"),
         ],
         [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"cancelGSD")],
         ]
        return await callback_query.edit_message_text(
            f"""
<blockquote><b>✨ price list promo userbot premium, untuk melihat harga/list promo silahkan untuk memilih salah satu tombol di bawah ini.</b></blockquote>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )

@PY.CALLBACK("SELESPROMO")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 ☎ Owner 」", url=f"http://t.me/Ryzesxx?text=uy+pak+promo+seles+userbot+prem+masih??")],
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"menulahWAK")],
         ]
        return await callback_query.edit_message_text(
            f"""
<b>✨ OPEN PROMO RESELLER USERBOT PREMIUM BY {bot.me.mention}</b>
<b>UNTUK SEMUA RESELLER WAJIB STORAN UNTUK SETIAP ADA PEMBELI USERBOT</b>
<b>( storan hanya mengirimkan bukti transfer buyer saja / screenshot )</b>

<b>‼️ Rules & Ketentuan kami:</b>
<b>__ • Bebas Create/Add Userbot ( Limit 1B - 3B )__</b>
<b>__ • Tidak Membagikan Akses Secara Gratis__</b>
<b>__ • Storan Terbanyak Akan Mendapatkan Free 1B ( Di Undi Setiap Bulan )__</b>

<b>🛒 Price List Promo Reseller Userbot:</b>
<b>__ • Rp. 20.000 Akses Limit 30Hari/1Bulan__</b>
<b>__ • Rp. 40.000 Akses Limit 60Hari/2Bulan__</b>
<b>__ • Rp. 60.000 Akses Limit 90Hari/3Bulan__</b>

<b>- Membeli Akses Reseller Silahkan Click Di Bawah Ini❗</b>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )

@PY.CALLBACK("ADMINPROMO")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 ☎ Owner 」", url=f"http://t.me/Ryzesxx?text=uy+pak+promo+admin+userbot+prem+masih??")],       
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"menulahWAK")],
         ]
        return await callback_query.edit_message_text(
            f"""
<b>✨ OPEN PROMO ADMiN USERBOT PREMIUM BY {bot.me.mention}</b>
<b>UNTUK SEMUA ADMIN WAJIB STORAN UNTUK SETIAP ADA PEMBELI USERBOT</b>
<b>( storan hanya mengirimkan bukti transfer buyer saja / screenshot )</b>

<b>‼️ Rules & Ketentuan kami:</b>
<b>__ • Bebas Create/Add Userbot ( Limit 1B - 3B )__</b>
<b>__ • Bebas Jualan Akses Reseller Userbot Sepuasnya.__</b>
<b>__ • Tidak Membagikan Akses Secara Gratis__</b>
<b>__ • Storan Terbanyak Akan Mendapatkan Free 1B ( Di Undi Setiap Bulan )__</b>

<b>🛒 Price List Promo Admin Userbot:</b>
<b>__ • Rp. 40.000 Akses Limit 30Hari/1Bulan__</b>
<b>__ • Rp. 80.000 Akses Limit 60Hari/2Bulan__</b>
<b>__ • Rp. 120.000 Akses Limit 90Hari/3Bulan__</b>

<b>- Membeli Akses Admin Silahkan Click Di Bawah Ini❗</b>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )


##############
        
@PY.CALLBACK("bahan")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 🔄 Restart 」", callback_data=f"ress_ubot")],
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
<blockquote><b>💬 anda sudah membuat userbot, jika bot tidak merespon silahkan klick tombol di bawah ini.</b></blockquote>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    elif len(ubot._ubot) + 1 > MAX_BOT:
        buttons = [
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
<blockquote><b>📛 anda tidak bisa membuat userbot saat ini❗</b>
<b>⚠️ karena maximal pengguna userbot telah mencapai: {Fonts.smallcap(str(len(ubot._ubot)))}</b>
<b>👉 jika ingin membuat userbot hubungi: <a href=tg://openmessage?user_id={OWNER_ID}>Ryzesxx</a> </b></blockquote>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    premium_users, ultra_premium_users = await get_list_from_vars(client.me.id, "PREM_USERS"), await get_list_from_vars(client.me.id, "ULTRA_PREM")
    if user_id not in premium_users and user_id not in ultra_premium_users:
        buttons = [
            [InlineKeyboardButton("「 ↪️ Lanjutkan 」", callback_data="bayar_dulu")],
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            MSG.POLICY(),
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    else:
        buttons = [[InlineKeyboardButton("「 ↪️ Lanjutkan 」", callback_data="buat_ubot")]]
        return await callback_query.edit_message_text(
            """
<b>ᴀɴᴅᴀ ᴛᴇʟᴀʜ ᴍᴇᴍ「 💵 Beli Userbot 」 ꜱɪʟᴀʜᴋᴀɴ ᴘᴇɴᴄᴇᴛ ᴛᴏᴍʙᴏʟ 「 ↪️ Lanjutkan 」 ᴜɴᴛᴜᴋ ᴍᴇᴍʙᴜᴀᴛ ᴜꜱᴇʀʙᴏᴛ</b>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )

@PY.CALLBACK("tutoriyal")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
<u><b>📚 Tutorial Membuat Trial Userbot</b></u>
<blockquote><b> ❄ Langkah 1: Ketik Di Userbot @Ryzesxx_bot, Klik Button ”𝖳𝗋𝗂𝖺𝗅 𝖴𝗌𝖾𝗋𝖻𝗈𝗍”, Baca Isi Notes & Resiko Memakai Userbot.</b></blockquote>
<blockquote><b> ✨ Langkah 2:  Jika Sudah Membaca Silahkan Klik Button ”𝖲𝖾𝗍𝗎𝗃𝗎”.</b></blockquote>
<blockquote><b> 🌸 Langkah 3: Klik Button ”𝖪𝖾𝗆𝖻𝖺𝗅𝗂”, Jika Sudah Klik Button ”𝖡𝗎𝖺𝗍 𝖴𝗌𝖾𝗋𝖻𝗈𝗍", Jangan Lupa Ikuti Arahan Dari Bot❗</b></blockquote>
<blockquote><b> 📃 Notes: Pemakaian Trial Userbot Hanya 1x, Seterusnya? Buy Modal Dikit.</b></blockquote>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
        
@PY.CALLBACK("status")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        exp = await get_expired_date(user_id)
        prefix = await get_pref(user_id)
        waktu = datetime.now(pytz.timezone('asia/Jakarta')).strftime("%d/%m/%Y") if exp else "none"
        return await callback_query.edit_message_text(
            f"""
<b>🤖 {bot.me.mention}</b>
<blockquote><b>🧾 status akun: premium.</b>
<b>📚 prefixes: {prefix[0]}</b>
<b>⏰ expired: {waktu}</b>
<b>👉 owner: @Ryzesxx</b></blockquote>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    else:
        buttons = [
            [InlineKeyboardButton("「 💵 Beli Userbot 」", callback_data=f"bahan")],
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
<b>🤖 USERBOT {bot.me.mention}</b>
<blockquote><b>🧾 status akun: none.</b>
<b>📚 prefixes: {prefix[0]}</b>
<b>⏰ expired: {waktu}</b>
<b>👉 owner: @Ryzesxx</b></blockquote>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
    )


@PY.CALLBACK("dukungani")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 ✨ Solusi 」", callback_data=f"solusi")],
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
📛 <u><b>Dukungan</b></u>
<blockquote><b>👉 Saran Menggunakan Userbot Awalan ID: 1, 2, 3, 4, 5, 6. Karena Akun Telegram Dengan Awalan ID Tersebut Menandakan Akun Yang Sudah Lama Mendaftar Ke Dalam Aplikasi Telegram. Untuk Pengguna Akun Awalan ID: 7, 8. Saya Tidak Menyarankan Untuk Menggunakan Userbot Premium!!. Karena Akun Akun Dengan Awalan ID Tersebut Menandakan Akun Baru Mendaftar Ke Dalam Aplikasi Telegram.</b></blockquote>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
@PY.CALLBACK("solusi")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"dukungani")],
        ]
        return await callback_query.edit_message_text(
            f"""
✨ <u><b>Solusi</b></u>
<blockquote><b>👉 untuk pengguna awalan id: 7, 8. akun wajib sudah untuk berinteraksi selama 2minggu - 3bulan. karena akun dengan awalan id tersebut bisa terkena deak/akun terhapus jika dalam kondisi fresh/baru. kalian bisa juga menggunakan telegram premium (hanya saran saja).</b></blockquote>""",
           disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
@PY.CALLBACK("buat_ubot")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 🔄 Restart 」", callback_data=f"ress_ubot")],
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
<blockquote><b>💬 anda sudah membuat userbot, jika bot tidak merespon silahkan klick tombol di bawah ini.</b></blockquote>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    elif len(ubot._ubot) + 1 > MAX_BOT:
        buttons = [
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
<blockquote><b>📛 anda tidak bisa membuat userbot saat ini❗</b>
<b>⚠️ karena maximal pengguna userbot telah mencapai: {Fonts.smallcap(str(len(ubot._ubot)))}</b>
<b>👉 jika ingin membuat userbot hubungi: <a href=tg://openmessage?user_id={OWNER_ID}>Ryzesxx</a> </b></blockquote>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    premium_users, ultra_premium_users = await get_list_from_vars(client.me.id, "PREM_USERS"), await get_list_from_vars(client.me.id, "ULTRA_PREM")
    if user_id not in premium_users and user_id not in ultra_premium_users:
        buttons = [
            [InlineKeyboardButton("「 💵 Beli Userbot 」", callback_data="bahan")],
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
<blockquote><b>❗ anda belum membeli akses userbot, silahkan hubungi: @Ryzesxx, untuk mendapatkan akses userbot</b><blockquote>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    else:
        buttons = [[InlineKeyboardButton("「 ↪️ Lanjutkan 」", callback_data="add_ubot")]]
        return await callback_query.edit_message_text(
            """
📚 <b>Untuk Membuat Userbot Siapkan Bahan-Bahan Berikut Ini:</b>
<blockquote><b> • Siapkan Nomor Telegram Akun.<b>
<b> • Siapkan a2f / Password Telegram. (Jika Sudah Aktif)</b></blockquote>
<b>👉 Jika Sudah Silahkan Untuk Klik Tombol Di Bawah Ini:</b>
<b>- Jika Ada Kendala Silahkan Hubungi: @Ryzesxx<b>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )

@PY.CALLBACK("bayar_dulu")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    buttons = BTN.PLUS_MINUS(1, user_id)
    return await callback_query.edit_message_text(
        MSG.TEXT_PAYMENT(30, 30, 1),
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(buttons),
    )


@PY.CALLBACK("add_ubot")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    await callback_query.message.delete()
    try:
        phone = await bot.ask(
            user_id,
            (
                "<blockquote><b>👉 silahkan kirimkan nomor ponsel akun telegram anda, seperti contoh: +62888XXXXX</b>"
                "\n<b>🆘 gunakan perintah /cancel untuk membatalkan membuat userbot</b></blockquote>"
            ),
            timeout=300,
        )
    except asyncio.TimeoutError:
        return await bot.send_message(user_id, "<b>💬 pembatalan otomatis, gunakan perintah /start untuk memulai ulang</b>")
    if await is_cancel(callback_query, phone.text):
        return
    phone_number = phone.text
    new_client = Ubot(
        name=str(callback_query.id),
        api_id=API_ID,
        api_hash=API_HASH,
        in_memory=False,
    )
    get_otp = await bot.send_message(user_id, "<b>🔔 sedang mengirim kode otp ke akun telegram anda, mohon tunggu sebentar. . . .</b>")
    await new_client.connect()
    try:
        code = await new_client.send_code(phone_number.strip())
    except ApiIdInvalid as AID:
        await get_otp.delete()
        return await bot.send_message(user_id, AID)
    except PhoneNumberInvalid as PNI:
        await get_otp.delete()
        return await bot.send_message(user_id, PNI)
    except PhoneNumberFlood as PNF:
        await get_otp.delete()
        return await bot.send_message(user_id, PNF)
    except PhoneNumberBanned as PNB:
        await get_otp.delete()
        return await bot.send_message(user_id, PNB)
    except PhoneNumberUnoccupied as PNU:
        await get_otp.delete()
        return await bot.send_message(user_id, PNU)
    except Exception as error:
        await get_otp.delete()
        return await bot.send_message(user_id, f"ERROR: {error}")
    try:
        sent_code = {
            SentCodeType.APP: "<a href=tg://openmessage?user_id=777000>ᴀᴋᴜɴ ᴛᴇʟᴇɢʀᴀᴍ</a> ʀᴇsᴍɪ",
            SentCodeType.SMS: "sᴍs ᴀɴᴅᴀ",
            SentCodeType.CALL: "ᴘᴀɴɢɢɪʟᴀɴ ᴛᴇʟᴘᴏɴ",
            SentCodeType.FLASH_CALL: "ᴘᴀɴɢɢɪʟᴀɴ ᴋɪʟᴀᴛ ᴛᴇʟᴇᴘᴏɴ",
            SentCodeType.FRAGMENT_SMS: "ꜰʀᴀɢᴍᴇɴᴛ sᴍs",
            SentCodeType.EMAIL_CODE: "ᴇᴍᴀɪʟ ᴀɴᴅᴀ",
        }
        await get_otp.delete()
        otp = await bot.ask(
            user_id,
            (
                "<blockquote><b>💬 silahkan kirimkan kode otp 5 dijit yang sudah terkirim di akun telegram anda</b>\n"
                "<b>👉 jika kode: 12345, silahkan tambahkan spasi, lalu kirimkan seperti contoh: 1 2 3 4 5</b>\n"
                "<b>🆘 gunakan perintah /cancel untuk membatalkan membuat userbot</b></blockquote>"
            ),
            timeout=300,
        )
    except asyncio.TimeoutError:
        return await bot.send_message(user_id, "<b>💬 pembatalan otomatis, gunakan perintah /start untuk memulai ulang</b>")
    if await is_cancel(callback_query, otp.text):
        return
    otp_code = otp.text
    try:
        await new_client.sign_in(
            phone_number.strip(),
            code.phone_code_hash,
            phone_code=" ".join(str(otp_code)),
        )
    except PhoneCodeInvalid as PCI:
        return await bot.send_message(user_id, PCI)
    except PhoneCodeExpired as PCE:
        return await bot.send_message(user_id, PCE)
    except BadRequest as error:
        return await bot.send_message(user_id, f"ERROR: {error}")
    except SessionPasswordNeeded:
        try:
            two_step_code = await bot.ask(
                user_id,
                "<blockquote><b>🔒 akun telegram anda telah mengaktifkan password a2f, jika ingin melanjutkan silahkan kirim password tersebut, jika untuk membatalkan silahkan gunakan perintah /cancel</b></blockquote>",
                timeout=300,
            )
        except asyncio.TimeoutError:
            return await bot.send_message(user_id, "<b>💬 pembatalan otomatis, gunakan perintah /start untuk memulai ulang</b>")
        if await is_cancel(callback_query, two_step_code.text):
            return
        new_code = two_step_code.text
        try:
            await new_client.check_password(new_code)
        except Exception as error:
            return await bot.send_message(user_id, f"ERROR: {error}")
    session_string = await new_client.export_session_string()
    await new_client.disconnect()
    new_client.storage.session_string = session_string
    new_client.in_memory = False
    bot_msg = await bot.send_message(
        user_id,
        "<b>🕡 sedang memproses restart, mohon tunggu sebentar. . . .</b>",
        disable_web_page_preview=True,
    )
    await new_client.start()
    if not user_id == new_client.me.id:
        ubot._ubot.remove(new_client)
        return await bot_msg.edit(
            "<b>❗mohon gunakan nomor ponsel telegram akun anda, nomor tersebut bukan berasal dari akun anda.</b>"
        )
    await add_ubot(
        user_id=int(new_client.me.id),
        api_id=API_ID,
        api_hash=API_HASH,
        session_string=session_string,
    )
#    await remove_from_vars(client.me.id, "PREM_USERS", user_id)
    for mod in loadModule():
        importlib.reload(importlib.import_module(f"PyroUbot.modules.{mod}"))
    SH = await ubot.get_prefix(new_client.me.id)
    buttons = [
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
    text_done = f"""
<b>🤖 BERHASIL DI AKTIFKAN</b>
<blockquote><b>🧾 akun : <a href=tg://user?id={new_client.me.id}>{new_client.me.first_name} {new_client.me.last_name or ''}</a></b>
<b>👤 your-id: {new_client.me.id}</b>
<b>📚 prefixes: {' '.join(SH)}</b>
<b>💬 harap join: @ALLPENGGUNALOGS untuk mendapatkan info update</b>
<b>👉 jika bot tidak merespon, silahkan gunakan perintah /restart</b></blockquote>
        """
    await bot_msg.edit(text_done, disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons))
    await bash("rm -rf *session*")
    await install_my_peer(new_client)
    try:
        await new_client.join_chat("Ryzesxxservice")
        await new_client.join_chat("Ryzesxx_offc")
        await new_client.join_chat("LOGGSHOT")
        await new_client.join_chat("ALLPENGGUNALOGS")
        await new_client.join_chat("NEWSUSERBOTCELESTIAL")
    except UserAlreadyParticipant:
        pass

    return await bot.send_message(
        LOGS_MAKER_UBOT,
        f"""
<b>❕ account: <a href=tg://user?id={new_client.me.id}>{new_client.me.first_name} {new_client.me.last_name or ''}</a> </b>
<b>🌤 ID-users: {new_client.me.id}</b>
<b>📚 owner-bot: @Ryzesxx</b>
<b>📝 notes: jangan lupa .addbl anjing</b>
""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "「 ⏰ Masa Aktif 」",
                        callback_data=f"cek_masa_aktif {new_client.me.id}",
                    )
                ],
            ]
        ),
        disable_web_page_preview=True,
)

async def is_cancel(callback_query, text):
    if text.startswith("/cancel"):
        await bot.send_message(
            callback_query.from_user.id, "<b>💬 pembatalan otomatis, gunakan perintah /start untuk memulai ulang</b>"
        )
        return True
    return False


@PY.BOT("control")
async def _(client, message):
    buttons = [
            [InlineKeyboardButton("「 🔄 Restart 」", callback_data=f"ress_ubot")],
        ]
    await message.reply(
            f"""
<blockquote><b>💬 jika ingin melakukan restart, silahkan klick tombol di bawah ini</b></blockquote>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )

@PY.CALLBACK("ress_ubot")
async def _(client, callback_query):
    if callback_query.from_user.id not in ubot._get_my_id:
        return await callback_query.answer(
            f"you don't have acces",
            True,
        )
    for X in ubot._ubot:
        if callback_query.from_user.id == X.me.id:
            for _ubot_ in await get_userbots():
                if X.me.id == int(_ubot_["name"]):
                    try:
                        ubot._ubot.remove(X)
                        ubot._get_my_id.remove(X.me.id)
                        UB = Ubot(**_ubot_)
                        await UB.start()
                        for mod in loadModule():
                            importlib.reload(
                                importlib.import_module(f"PyroUbot.modules.{mod}")
                            )
                        return await callback_query.edit_message_text(
                            f"<b>🔃 𝖱𝖾𝗌𝗍𝖺𝗋𝗍 𝖡𝖾𝗋𝗁𝖺𝗌𝗂𝗅 𝖣𝗂 𝖫𝖺𝗄𝗎𝗄𝖺𝗇 𝖮𝗅𝖾𝗁 𝖯𝖾𝗇𝗀𝗀𝗎𝗇𝖺:</b>\n<b>📚 𝖯𝖾𝗇𝗀𝗀𝗎𝗇𝖺: {UB.me.first_name} {UB.me.last_name or ''} </b>\n<b>👉 𝖨𝖣-𝖴𝗌𝖾𝗋: {UB.me.id}</b>"
                        )
                    except Exception as error:
                        return await callback_query.edit_message_text(f"{error}")

@PY.BOT("restart")
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    if message.from_user.id not in ubot._get_my_id:
        return await msg.edit(
            f"you don't have acces",
            True,
        )
    for X in ubot._ubot:
        if message.from_user.id == X.me.id:
            for _ubot_ in await get_userbots():
                if X.me.id == int(_ubot_["name"]):
                    try:
                        ubot._ubot.remove(X)
                        ubot._get_my_id.remove(X.me.id)
                        UB = Ubot(**_ubot_)
                        await UB.start()
                        for mod in loadModule():
                            importlib.reload(
                                importlib.import_module(f"PyroUbot.modules.{mod}")
                            )
                        return await msg.edit(
                            f"<b>🔃 𝖱𝖾𝗌𝗍𝖺𝗋𝗍 𝖡𝖾𝗋𝗁𝖺𝗌𝗂𝗅 𝖣𝗂 𝖫𝖺𝗄𝗎𝗄𝖺𝗇 𝖮𝗅𝖾𝗁 𝖯𝖾𝗇𝗀𝗀𝗎𝗇𝖺:</b>\n<b>👤 𝖯𝖾𝗇𝗀𝗀𝗎𝗇𝖺: {UB.me.first_name} {UB.me.last_name or ''} </b>\n<b>👉 𝖨𝖣-𝖴𝗌𝖾𝗋: `{UB.me.id}`</b>"
                        )
                    except Exception as error:
                        return await msg.edit(f"{error}")

@PY.CALLBACK("cek_ubot")
@PY.BOT("getubot")
@PY.ADMIN
async def _(client, callback_query):
    await bot.send_message(
        callback_query.from_user.id,
        await MSG.UBOT(0),
        reply_markup=InlineKeyboardMarkup(BTN.UBOT(ubot._ubot[0].me.id, 0)),
    )

@PY.CALLBACK("cek_masa_aktif")
async def _(client, callback_query):
    user_id = int(callback_query.data.split()[1])
    expired = await get_expired_date(user_id)
    try:
        xxxx = (expired - datetime.now()).days
        return await callback_query.answer(f"❗Tersisa: {xxxx} Hari", True)
    except:
        return await callback_query.answer("Sudah Tidak Aktif", True)


@PY.CALLBACK("del_ubot")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id not in await get_list_from_vars(client.me.id, "ADMIN_USERS"):
        return await callback_query.answer(
            f"<b>❗ 𝖳𝗈𝗆𝖻𝗈𝗅 𝖨𝗇𝗂 𝖡𝗎𝗄𝖺𝗇 𝖴𝗇𝗍𝗎𝗄 𝖬𝗎: {callback_query.from_user.first_name} {callback_query.from_user.last_name or ''}</b>",
            True,
        )
    try:
        show = await bot.get_users(callback_query.data.split()[1])
        get_id = show.id
        get_mention = f"{get_id}"
    except Exception:
        get_id = int(callback_query.data.split()[1])
        get_mention = f"{get_id}"
    for X in ubot._ubot:
        if get_id == X.me.id:
            await X.unblock_user(bot.me.username)
            await remove_ubot(X.me.id)
            ubot._get_my_id.remove(X.me.id)
            ubot._ubot.remove(X)
            await X.log_out()
            await callback_query.answer(
                f"{get_mention} Bershasil Terhapus", True
            )
            await callback_query.edit_message_text(
                await MSG.UBOT(0),
                reply_markup=InlineKeyboardMarkup(
                    BTN.UBOT(ubot._ubot[0].me.id, 0)
                ),
            )
            await bot.send_message(
                X.me.id,
                MSG.EXP_MSG_UBOT(X),
                reply_markup=InlineKeyboardMarkup(BTN.EXP_UBOT()),
            )


    
@PY.CALLBACK("^(p_ub|n_ub)")
async def _(client, callback_query):
    query = callback_query.data.split()
    count = int(query[1])
    if query[0] == "n_ub":
        if count == len(ubot._ubot) - 1:
            count = 0
        else:
            count += 1
    elif query[0] == "p_ub":
        if count == 0:
            count = len(ubot._ubot) - 1
        else:
            count -= 1
    await callback_query.edit_message_text(
        await MSG.UBOT(count),
        reply_markup=InlineKeyboardMarkup(
            BTN.UBOT(ubot._ubot[count].me.id, count)
        ),
    )
@PY.CALLBACK("closeHELP")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 📚 Plugins 」", callback_data=f"help_back")],
        ]
        return await callback_query.edit_message_text(
            f"""
<blockquote><b>✨ inline help ditutup, silahkan klik tombol di bawah ini untuk memunculkan kembali</b></blockquote>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
        


@PY.CALLBACK("listubot")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [
            InlineKeyboardButton("「 🧾 List Sewa 」", callback_data=f"lssewa"),
            InlineKeyboardButton("「 🧾 List Seles 」", callback_data=f"lsseles")
            ],
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"""
<blockquote><b>🧾 harga dan list userbot ada di salah satu tombol di bawah ini, silahkan pilih salah satu tombol dibawah ini</b>❗</blockquote>
""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )

@PY.CALLBACK("lssewa")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 🏡 Home 」", callback_data=f"home {user_id}")],       
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"listubot")],
         ]
        return await callback_query.edit_message_text(
            f"""
🧾 <u><b>PRICE LIST AKSES SEWA USERBOT❕</b></u>
<blockquote><b>📚 Sewa Userbot: Rp. 15.000 (  30 Hari  ) </b>
<b>✨ Sewa Userbot: Rp. 30.000 (  60 Hari  )</b>
<b>🛒 Sewa Userbot: Rp. 40.000 (  90 Hari  ) </b>
<b>🌸 Sewa Userbot: Rp. 50.000 ( 150 Hari ) </b>
<b>✏️ Sewa Userbot: Rp. 60.000 ( 180 Hari ) </b>
<b>👉 Sewa Userbot: Rp. 70.000 ( 210 Hari )</b></blockquote>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )

@PY.CALLBACK("lsseles")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    if user_id in ubot._get_my_id:
        buttons = [
            [InlineKeyboardButton("「 🏡 Home 」", callback_data=f"home {user_id}")],       
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"listubot")],
         ]
        return await callback_query.edit_message_text(
            f"""
🧾 <u><b>PRICE LIST AKSES SELES USERBOT❕</b></u>
<blockquote><b>📚 Seles Userbot: Rp. 30.000 (  30 Hari  ) </b>
<b>✨ Seles Userbot: Rp. 60.000 (  60 Hari  )</b>
<b>🛒 Seles Userbot: Rp. 80.000 (  90 Hari  ) </b>
<b>🌸 Seles Userbot: Rp. 100.000 ( 150 Hari ) </b>
<b>✏️ Seles Userbot: Rp. 120.000 ( 180 Hari ) </b>
<b>👉 Seles Userbot: Rp. 140.000 ( 210 Hari )</b></blockquote>""",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )


async def cek_trial(client, user_id):
    gettrial = await get_list_from_vars(client, "USER_TRIAL")
    if user_id in gettrial:
        return True
    return False

@PY.CALLBACK("^trial_ubot")
async def cb_trial_tanya(client, cq):
    user_id = cq.from_user.id
    msg = f"""
<b><blockquote>📛 masa aktif trial: [ 1 𝖧𝖺𝗋𝗂 0 𝖩𝖺𝗆 ] harap membaca resiko & syarat penggunaan userbot</b>
<b>✨ saran menggunakan awalan id 1, 2, 3, 4, 5, 6 karena menandakan akun awam/lama.</blockquote></b>
<b>👉 silahkan pilih salah satu tombol di bawah ini❗</b>"""
    batin = InlineKeyboardMarkup([
        [InlineKeyboardButton("「 ↪️ Setuju 」", callback_data="ok_trial"), 
         InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")],
        [InlineKeyboardButton("「 🧾 Tutorial 」", callback_data=f"tutoriyal")]
        ])
    return await cq.edit_message_text(msg, reply_markup=batin)

@PY.CALLBACK("^gaktrial")
async def cb_gajadi_trial(client, cq):
    user_id = cq.from_user.id
    buttons = BTN.START(cq.message)
    msg = MSG.START(cq.message)
    return await cq.edit_message_text(msg, disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup(buttons))

@PY.CALLBACK("^ok_trial")
async def cb_oke_trial(client, cq):
    user_id = cq.from_user.id
    data = await cek_trial(client.me.id, user_id)
    
    if data:
        msg = """
<b><blockquote>❗Percobaan Trial Userbot Hanya 1x, Untuk Memakai Userbot Lagi Silahkan Hubungi Owner Saya: @Ryzesxx</blockquote></b>"""
        batin = InlineKeyboardMarkup([
            [InlineKeyboardButton("「 ↩️ Kembali 」", callback_data=f"home {user_id}")]
        ])
        return await cq.edit_message_text(msg, reply_markup=batin)
    else:
        now = datetime.now(timezone("Asia/Jakarta"))
        expired = now + relativedelta(hours=25)
        await add_to_vars(client.me.id, "USER_TRIAL", user_id)
        await set_expired_date(user_id, expired)
        
        msg = "<b>❗Trial Userbot Anda Sudah Di Aktifkan, Silahkan Buat Userbot.</b>"
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("「 ↪️ Lanjutkan 」", callback_data="add_ubot")]
        ])
        return await cq.edit_message_text(msg, reply_markup=buttons)
