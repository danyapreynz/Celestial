from PyroUbot import *
import random
import requests
from pyrogram.enums import ChatAction, ParseMode
from pyrogram import filters
from pyrogram.types import Message

__MODULE__ = "img2prompt"
__HELP__ =  """📖 <u><b>Folder Module Img2Prompt</b></u>

<blockquote><b>📚 perintah: .img2prompt [ʟɪɴᴋ]</b>
<b>📝 penjelasan: untuk mencari kata yang berasal dari foto</b></blockquote>"""

def get_text(message):
    if message.reply_to_message:
        if len(message.text.split()) < 2:
            text = message.reply_to_message.text or message.reply_to_message.caption
        else:
            text = f"{message.reply_to_message.text or message.reply_to_message.caption}\n\n{message.text.split(None, 1)[1]}"
    else:
        if len(message.text.split()) < 2:
            text = ""
        else:
            text = message.text.split(None, 1)[1]
    return text
    
@PY.UBOT("img2prompt")
@PY.TOP_CMD
async def _(client, message):
    try:
        prs = await message.reply_text(f"<b>💬 was running wait a minute. ✨</b>")
        link = get_text(message)
        
        if not link:
            return await prs.edit(f"<b><code>{message.text}</code> [ʟɪɴᴋ]</b>")
        
        response = requests.get(f'https://api.botcahx.eu.org/api/tools/img2prompt?url={link}&apikey=VENOZY')
        
        try:
            if "result" in response.json():
                x = response.json()["result"]
                await prs.edit(
                    f"{x}\n<blockquote><b>--  --</b></blockquote>"
                )
            else:
                await message.reply_text("no 'results' key found in the response.")
        except KeyError:
            await message.reply_text("error accessing the response.")
    
    except Exception as e:
        await message.reply_text(f"an error occurred: {e}")
