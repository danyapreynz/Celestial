import random
from pyrogram.enums import MessagesFilter
from PyroUbot import *

__MODULE__ = "bokexp"
__HELP__ =  """📖 <u><b>Folder Module Bokexp</b></u>

<blockquote><b>📚 perintah: .bokep</b>
<b>📝 penjelasan: untuk mencari asupan video bokep</b></blockquote>
<blockquote><b>📚 perintah: .random</b>
<b>📝 penjelasan: untuk mencari video bokep random</b></blockquote>
<blockquote><b>📚 perintah: .vvip</b>
<b>📝 penjelasan: untuk mencari video bokep vvip</b></blockquote>"""


@PY.UBOT("bokep")
@PY.TOP_CMD
async def video_asupan(client, message):
    prs = await EMO.PROSES(client)
    y = await message.reply_text(f"<b>💬 was running wait a minute. ✨</b>")
    try:
        asupannya = []
        async for asupan in client.search_messages(
            "@vvideo_viral", filter=MessagesFilter.VIDEO
        ):
            asupannya.append(asupan)
        video = random.choice(asupannya)
        await video.copy(message.chat.id, reply_to_message_id=message.id)
        await y.delete()
    except Exception as error:
        await y.edit(error)


@PY.UBOT("random")
@PY.TOP_CMD
async def video_asupan(client, message):
    prs = await EMO.PROSES(client)
    y = await message.reply_text(f"<b>💬 was running wait a minute. ✨</b>")
    try:
        asupannya = []
        async for asupan in client.search_messages(
            "@asupan18tocrot", filter=MessagesFilter.VIDEO
        ):
            asupannya.append(asupan)
        video = random.choice(asupannya)
        await video.copy(message.chat.id, reply_to_message_id=message.id)
        await y.delete()
    except Exception as error:
        await y.edit(error)
        
@PY.UBOT("vvip")
@PY.TOP_CMD
async def video_asupan(client, message):
    prs = await EMO.PROSES(client)
    y = await message.reply_text(f"<b>💬 was running wait a minute. ✨</b>")
    try:
        asupannya = []
        async for asupan in client.search_messages(
            "@asupan18tocrot", filter=MessagesFilter.VIDEO
        ):
            asupannya.append(asupan)
        video = random.choice(asupannya)
        await video.copy(message.chat.id, reply_to_message_id=message.id)
        await y.delete()
    except Exception as error:
        await y.edit(error)
 
 

