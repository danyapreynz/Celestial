import requests
from pyrogram import Client, filters
from PyroUbot import *

__MODULE__ = "simi ai"
__HELP__ =  """📖 <u><b>Folder Module Simi Ai</b></u>

<blockquote><b>📚 perintah: .simi [ᴍᴇssᴀɢᴇ]</b>
<b>📝 penjelasan: untuk chat dengan simi ai</b></blockquote>"""

@PY.UBOT("simi")
async def _(client, message):
    if len(message.command) < 2:
        await message.reply_text("<b>👉 Gunakan Perintah: .simi [ᴍᴇssᴀɢᴇ]</b>")
        return
    
    chatsimi = " ".join(message.command[1:])
    url = f"https://api.botcahx.eu.org/api/search/simsimi?query={chatsimi}&apikey=VENOZY"
    
    response = requests.get(url)
    
    if response.status_code == 200:
        item = response.json()
        if item["status"]:
            await message.reply_text(f"""{item['result']}""")
        else:
            await message.reply_text("eror")
    else:
        await message.reply_text("eror")
