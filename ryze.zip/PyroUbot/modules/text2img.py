import os
from PyroUbot import *
import requests

__MODULE__ = "text2img"
__HELP__ =  """📖 <u><b>Folder Module Text2Ing</b></u>

<blockquote><b>📚 perintah: .text2img</b>
<b>📝 penjelasan: untuk membuat text prompt</b></blockquote>"""

def get_text2img_image(text):
    url = "https://api.botcahx.eu.org/api/maker/text2img"
    params = {
        "text": text,
        "apikey": "VENOZY"
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None
        
@PY.UBOT("text2img")
async def _(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("gunakan perintah .text2img <teks> untuk membuat gambar.")
        return

    request_text = args[1]
    processing_msg = await message.edit("<b>💬 was running wait a minute. ✨</b>")

    image_content = get_text2img_image(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah....")
