__MODULE__ = "logs"
__HELP__ = """📖 <u><b>Folder Module Logs</b></u>

<blockquote><b>📚 perintah: .logs [ᴏɴ/ᴏғғ]</b>
<b>📝 penjelasan: untuk mengaktifkan / menonaktifkan pesan yang membalas anda</b></blockquote>"""
