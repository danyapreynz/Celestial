from pyrogram import Client, filters
import requests
import os
import mimetypes
from PyroUbot import *

__MODULE__ = "mediafire"
__HELP__ =   """📖 <u><b>Folder Module Media Fire</b></u>

<blockquote><b>📚 perintah: .mediafire [link]</b>
<b>📝 penjelasan: untuk mendownload link mediafire</b></blockquote>"""

@PY.UBOT("mediafire")
async def _(client, message):
    args = message.text.split(" ", 1)

    if len(args) < 2:
        await message.reply_text("<u><b>❗Mohon Gunakan Format: .MediaFire [link]</b></u>", quote=True)
        return

    mediafire_url = args[1]
    api_url = f"https://api.botcahx.eu.org/api/download/mediafire?url={mediafire_url}&apikey=VENOZY"

    try:
        response = requests.get(api_url)
        data = response.json()

        if data.get("status") and "result" in data:
            file_info = data["result"]
            filename = file_info["filename"]
            filesize = file_info["filesize"]
            file_url = file_info["url"]

            downloading_msg = await message.reply_text(f"<b>Sedang Mengunduh: {filename}</b>\n<b>Size: {filesize}</b>", quote=True)

            file_path = f"./{filename}"
            file_response = requests.get(file_url, stream=True)

            with open(file_path, "wb") as file:
                for chunk in file_response.iter_content(chunk_size=1024):
                    if chunk:
                        file.write(chunk)

            mime_type, _ = mimetypes.guess_type(file_path)

            if mime_type:
                if mime_type.startswith("image"):
                    await message.reply_photo(file_path, caption=f"📚 **Gambar Berhasil Diunduh❗**\n📂 <b>Nama: {filename}</b>\n📝 <b>Size: {filesize} </b>")
                elif mime_type.startswith("video"):
                    await message.reply_video(file_path, caption=f"📚 **Video Berhasil Diunduh❗**\n📂 <b>Nama: {filename}</b>\n📝 <b>Size: {filesize} </b>")
                elif mime_type.startswith("audio"):
                    await message.reply_audio(file_path, caption=f"📚 **Audio Berhasil Diunduh❗**\n📂 <b>Nama: {filename}</b>\n📝 <b>Size: {filesize} </b>")
                else:
                    await message.reply_document(file_path, caption=f"📚 **File Berhasil Diunduh❗**\n📂 <b>Nama: {filename}</b>\n📝 <b>Size: {filesize} </b>")
            else:
                await message.reply_document(file_path, caption=f"📚 **File Berhasil Diunduh❗**\n📂 <b>Nama: {filename}</b>\n📝 <b>Size: {filesize} </b>")

            os.remove(file_path)

            await downloading_msg.delete()
        else:
            await message.reply_text("⚠️ Gagal mendapatkan informasi file dari Mediafire.", quote=True)
    except Exception as e:
        await message.reply_text(f"❌ Terjadi kesalahan:\n`{str(e)}`", quote=True)
        
