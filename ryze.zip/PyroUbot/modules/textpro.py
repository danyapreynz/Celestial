import os
from PyroUbot import *
import requests

__MODULE__ = "textpro"
__HELP__ = """📖 <u><b>Folder Module TextPro</b></u>

<b>★ ᴘᴇʀɪɴᴛᴀʜ: .3dstone</b>
<b>╰ ᴘᴇɴᴊᴇʟᴀsᴀɴ: untuk membuat textpro 3dstone</b></blockquote>
<b>★ ᴘᴇʀɪɴᴛᴀʜ: .porn</b>
<b>╰ ᴘᴇɴᴊᴇʟᴀsᴀɴ: untuk membuat textpro porn</b></blockquote>
<b>★ ᴘᴇʀɪɴᴛᴀʜ: .hallowen</b>
<b>╰ ᴘᴇɴᴊᴇʟᴀsᴀɴ: untuk membuat textpro hallowen</b> </blockquote>
<b>★ ᴘᴇʀɪɴᴛᴀʜ: .ice</b>
<b>╰ ᴘᴇɴᴊᴇʟᴀsᴀɴ: untuk membuat textpro robot</b></blockquote>
<b>★ ᴘᴇʀɪɴᴛᴀʜ: .blood</b>
<b>╰ ᴘᴇɴᴊᴇʟᴀsᴀɴ: untuk membuat textpro horor</b></blockquote>"""

def get_brat_image(text):
    url = "https://api.betabotz.eu.org/api/textpro/3dstone"
    params = {
        "text": text,
        "apikey": "VENOZY"
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None
            
def magma(text):
    url = "https://api.betabotz.eu.org/api/textpro/pornhub"
    params = {
        "text": text,
        "apikey": "VENOZY"
    }  
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None
            
def Halloween(text):
    url = "https://api.betabotz.eu.org/api/textpro/hallowen"
    params = {
        "text": text,
        "apikey": "VENOZY"
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None
            
def robott(text):
    url = "https://api.betabotz.eu.org/api/textpro/ice"
    params = {
        "text": text,
        "apikey": "VENOZY"
    }   
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None
            
def horor(text):
    url = "https://api.betabotz.eu.org/api/textpro/horor-blood"
    params = {
        "text": text,
        "apikey": "VENOZY"
    }                       
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None
        
@PY.UBOT("Blood|blood")
async def _(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .blood peno")
        return

    request_text = args[1]
    processing_msg = await message.edit("<b>💬 was running wait a minute. ✨</b>")

    image_content = horor(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")
                              
@PY.UBOT("ice|Ice")
async def _(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .ice peno")
        return

    request_text = args[1]
    processing_msg = await message.edit("<b>💬 was running wait a minute. ✨</b>")

    image_content = robott(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")
                                  
@PY.UBOT("Halloween|halloween")
async def _(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .halloween peno")
        return

    request_text = args[1]
    processing_msg = await message.edit("<b>💬 was running wait a minute. ✨</b>")

    image_content = Halloween(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")
                             
@PY.UBOT("Porn|porn")
async def _(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .porn peno")
        return

    request_text = args[1]
    processing_msg = await message.edit("<b>💬 was running wait a minute. ✨</b>")

    image_content = Magma(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")
                
@PY.UBOT("3dstone|3dstone")
async def _(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .3dstone peno")
        return

    request_text = args[1]
    processing_msg = await message.edit("<b>💬 was running wait a minute. ✨</b>")

    image_content = get_brat_image(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")
