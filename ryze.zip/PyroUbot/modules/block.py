from PyroUbot import *
from pyrogram.raw.functions.contacts import GetBlocked

__MODULE__ = "block"
__HELP__ =  """📖 <u><b>Folder Module Block</b></u>

<blockquote><b>📚 perintah: .unblockall</b>
<b>📝 penjelasan: untuk unblock semua contact yang terkena block</b></blockquote>
<blockquote><b>📚 perintah: .getblock </b>
<b>📝 penjelasan: untuk melihat jumlah contact yang di block</b></blockquote>"""

@PY.UBOT("unblockall")
async def _(user, message):
    sks = await EMO.BERHASIL(user)
    prs = await EMO.PROSES(user)
    _prs = await message.reply(f"<b>💬 was running wait a minute. ✨</b>")
    mecha = await user.invoke(GetBlocked(offset=0, limit=100))
    user_ids = [entry.peer_id.user_id for entry in mecha.blocked]
    for x in user_ids:
        try:
            await user.unblock_user(x)
        except:
            pass
    await _prs.edit(f"<b>👉 Berhasil Unblock Semua Contact Yang Terkena Block</b>")

@PY.UBOT("getblock")
async def _(user, message):
    prs = await EMO.PROSES(user)
    _prs = await message.reply(f"<b>💬 was running wait a minute. ✨</b>")
    mecha = await user.invoke(GetBlocked(offset=0, limit=100))
    user_ids = [entry.peer_id.user_id for entry in mecha.blocked]
    teko = len(user_ids)
    if user_ids:
        try:
            await _prs.edit(f"<b>❗ Block: {teko} Users</b>")
        except Exception as i:
            await _prs.edit(f"{i}")
    else:
        await _prs.edit(f"<b>✨ Tidak Ada Yang Terblokir</b>")
