import asyncio
from datetime import datetime
from gc import get_objects
from time import time

from pyrogram.raw.functions import Ping
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from PyroUbot import *

@PY.BOT("start")
@PY.START
@PY.PRIVATE
async def _(client, message):
    if len(message.command) < 2:
        buttons = BTN.START(message)
        msg = MSG.START(message)
        song = "https://files.catbox.moe/oygidp.mp3"
        poto = "https://files.catbox.moe/6ftccd.jpg"
        await bot.send_photo(
        chat_id=message.chat.id,
        photo=poto,
        caption=msg,
        reply_markup=InlineKeyboardMarkup(buttons))
        await bot.send_audio(
        chat_id=message.chat.id,
        audio=song)

        
        
        
