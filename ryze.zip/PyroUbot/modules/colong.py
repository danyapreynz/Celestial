__MODULE__ = "colong"
__HELP__ =  """📖 <u><b>Folder Module Colong</b></u>

<blockquote><b>📚 perintah: .colong</b>
<b>📝 penjelasan: untuk menyimpan foto 1x lihat</b></blockquote>"""
