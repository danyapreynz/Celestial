__MODULE__ = "qr code"
__HELP__ = """📖 <u><b>Folder Module Qr Code</b></u>

<blockquote><b>📚 perintah: .qrgen</b>
<b>📝 penjelasan: untuk merubah text jadi gambar qr</b></blockquote>
<blockquote><b>📚 perintah: .qrread</b>
<b>📝 penjelasan: untuk merubah qr menjadi text</b></blockquote>"""