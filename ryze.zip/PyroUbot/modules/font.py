__MODULE__ = "font"
__HELP__ = """📖 <u><b>Folder Module Font</b></u>

<blockquote><b>📚 perintah: .font [ʀᴇᴘʟʏ/ᴛᴇxᴛ]</b>
<b>📝 penjelasan: untuk mengubah style font yang berbeda</b></blockquote>"""