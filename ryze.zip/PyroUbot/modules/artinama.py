import requests
from pyrogram import Client, filters
from PyroUbot import *

__MODULE__ = "artinama"
__HELP__ =  """📖 <u><b>Folder Module Arti Nama</b></u>

<blockquote><b>📚 perintah: .artinama [ɴᴀᴍᴀ]</b>
<b>📝 penjelasan: untuk mwncari makna tersembunyi dibalik namamu</b></blockquote>"""

@PY.UBOT("artinama")
async def _(client, message):
    if len(message.command) < 2:
        await message.reply_text("<b> ɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ: .artinama [ɴᴀᴍᴀ]</b>\n<b>ᴜɴᴛᴜᴋ ᴍᴇɴᴄᴀʀɪ ᴍᴀᴋɴᴀ ᴛᴇʀsᴇᴍʙᴜɴʏɪ ᴅɪ ʙᴀʟɪᴋ ɴᴀᴍᴀᴍᴜ</b>")
        return
    
    name = " ".join(message.command[1:])
    url = f"https://api.botcahx.eu.org/api/primbon/artinama?nama={name}&apikey=VENOZY"
    
    await message.reply_text("<b>💬 was running wait a minute. ✨</b>")
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if data["status"]:
            await message.reply_text(f"<blockquote>{data['result']['message']['arti']}\n\n🤩 Bagaimana Terlihat Menarik bukan</blockquote>")
        else:
            await message.reply_text("**__ups! nama yang kamu cari tidak ditemukan. coba lagi dengan nama lain!__**")
    else:
        await message.reply_text("**__⚠️ gagal mengambil data dari api. coba lagi nanti!__**")
        
###############
        
@PY.UBOT("artimimpi")
async def _(client, message):
    if len(message.command) < 2:
        await message.reply_text("<b> ɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ: .artimimpi [ᴍɪᴍᴘɪ]</b>\n<b>ᴜɴᴛᴜᴋ ᴍᴇɴᴄᴀʀɪ ᴀʀᴛɪ ᴅᴀʀɪ ᴍɪᴍᴘɪ ᴛᴇʀsᴇʙᴜᴛ</b>")
        return
    
    mimpi = " ".join(message.command[1:])
    url = f"https://api.botcahx.eu.org/api/primbon/artimimpi?mimpi={mimpi}&apikey=VENOZY"
    
    await message.reply_text("<b>💬 was running wait a minute. ✨</b>")
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if data["status"]:
            await message.reply_text(f"<blockquote>{data['result']['message']['arti']}\n\n😶‍🌫️ Bagaimana mimpimu apakah positif atau negatif?</blockquote>")
        else:
            await message.reply_text("**__ups! mimpi yang kamu cari tidak ditemukan. coba lagi dengan nama lain!__**")
    else:
        await message.reply_text("**__⚠️ gagal mengambil data dari api. coba lagi nanti!__**")
        