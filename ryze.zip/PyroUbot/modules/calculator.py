from pyrogram import Client, filters
import math
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from PyroUbot import *

__MODULE__ = "calculator"
__HELP__ = """📖 <u><b>Folder Module Calculator</b></u>

<blockquote><b>📚 perintah: .calculator</b>
<b>📝 penjelasan: untuk menghitung jumlah angka</b></blockquote>"""


@PY.UBOT("calculator")
async def calculator(client, message):
    if len(message.command) < 2:
        await message.reply_text("<b>🌸 Gunakan Format:</b>\n<b>.calculator 2+2×3</b>")
        return

    text = " ".join(message.command[1:])
    val = (
        text.replace("×", "*")
        .replace("÷", "/")
        .replace("π", "math.pi")
        .replace("pi", "math.pi")
        .replace("e", "math.e")
        .replace("E", "math.e")
    )
    
    allowed_chars = "0123456789-+*/().mathpie "
    if any(char not in allowed_chars for char in val.replace("math.", "")):
        await message.reply_text("**__Format salah, hanya 0-9 dan simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport__**")
        return

    try:
        result = eval(val)
        if result is None:
            raise ValueError("Isinya?")

        format_text = (
            text.replace("math.pi", "π")
            .replace("math.e", "e")
            .replace("/", "÷")
            .replace("*", "×")
        )

        await message.reply_text(f"<b>__{format_text} = {result}__</b>")
    except:
        await message.reply_text("**__format salah, hanya 0-9 dan simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport__**")
