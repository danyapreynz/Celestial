from pyrogram import Client, filters
import requests
from PyroUbot import *

__MODULE__ = "happymod"
__HELP__ = f"""📖 <u><b>Folder Module HappyMOD</b></u>>

<blockquote><b>📚 perintah: .happymod [ᴀᴘʟɪᴋᴀsɪ]</b>
<b>📝 penjelasan: untuk mencari aplikasi di happymod</b></blockquote>"""

@PY.UBOT("happymod")
async def _(client, message):
    args = message.text.split(" ", 1)

    if len(args) < 2:
        await message.reply_text("<b>📚 Gunakan Format:</b>\n<b>🌸 .happymod [aplikasi]</b>", quote=True)
        return

    query = args[1]
    api_url = f"https://api.botcahx.eu.org/api/search/happymod?query={query}&apikey=VENOZY"

    try:
        response = requests.get(api_url)
        data = response.json()

        if not data.get("status") or "result" not in data:
            await message.reply_text("<b>⚠️ Tidak Di Temukan Hasil Untuk Pencarian ini.</b>", quote=True)
            return

        results = data["result"][:5]
        response_text = "🔍 **Hasil Pencarian HappyMod:**\n\n"

        for item in results:
            title = item["title"]
            icon = item["icon"]
            rating = item["rating"]
            link = item["link"]

            response_text += (
                f"""
<b>__📌 {title}__</b>
<b>__⭐ Rating: {rating}__</b>
<b>__🔗 [Unduh di HappyMod]({link})__</b>"""
            )

        await message.reply_text(response_text, disable_web_page_preview=True, quote=True)
    except Exception as e:
        await message.reply_text(f"<b>Terjadi Kesalahan:</b>\n`{str(e)}`", quote=True)
