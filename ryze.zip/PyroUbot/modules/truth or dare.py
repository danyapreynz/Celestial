import asyncio
import random
from PyroUbot.modules import pertanyaan_JEMBUT as PENODEK
from PyroUbot import *

__MODULE__ = "truth dare"
__HELP__ = """📖 <u><b>Folder Module Truth Dare</b></u>

<blockquote><b>📚 perintah: .truth</b>
<b>📝 penjelasan: untuk sebuah kejujuran</b></blockquote>
<blockquote><b>📚 perintah: .dare</b>
<b>📝 penjelasan: untuk sebuah tantangan</b></blockquote>"""

@PY.UBOT("dare")
async def dare(client, message):
    try:        
        await message.edit(f"{random.choice(PENODEK.DARE)}")
    except BaseException:
        pass
@PY.UBOT("truth")
async def truth(client, message):
    try:
        await message.edit(f"{random.choice(PENODEK.TRUTH)}")
    except Exception:
        pass
