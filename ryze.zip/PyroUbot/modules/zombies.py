__MODULE__ = "zombies"
__HELP__ =  """📖 <u><b>Folder Module Zombies</b></u>

<blockquote><b>📚 perintah: .zombies</b>
<b>📝 penjelasan: untuk mengeluarkan akun terhapus</b></blockquote>"""
