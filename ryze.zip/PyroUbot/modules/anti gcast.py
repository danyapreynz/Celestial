import asyncio
import os
import re

from pyrogram import filters
from pyrogram.enums import ChatType
from pyrogram.errors.exceptions.bad_request_400 import MessageTooLong
from PyroUbot import *
from PyroUbot.core.database import mongo_client

__MODULE__ = "antigcast"
__HELP__ = """📖 <u><b>Folder Module AntiGcast</b></u>

<blockquote><b>📚 perintah: .on or .off</b>
<b>📝 penjelasan: untuk mengaktifkan / menonaktifkan antigcast</b></blockquote>
<blockquote><b>📚 perintah: .cekatgs</b>
<b>📝 penjelasan: untuk melihat status antigcast on / off</b></blockquote>
<blockquote><b>📚 perintah: .addgroup</b>
<b>📝 penjelasan: untuk menambahkan group ke dalam database antigcast</b></blockquote>
<blockquote><b>📚 perintah: .deletegroup</b>
<b>📝 penjelasan: untuk menghapus group antigcast di dalam database</b></blockquote>
<blockquote><b>📚 perintah: .listgc or .listgroup</b>
<b>📝 penjelasan: untuk melihat database list group antigcast</b></blockquote>
<blockquote><b>📚 perintah: .addmsg [ʀᴇᴘʟʏ]</b>
<b>📝 penjelasan: untuk menambah pesan yang di larang antigcast</b></blockquote>
<blockquote><b>📚 perintah: .listmsg</b>
<b>📝 penjelasan: untuk melihat pesan yang di larang antigcast</b></blockquote>
<blockquote><b>📚 perintah: .deletemsg</b>
<b>📝 penjelasan: untuk menghapus pesan yang di larang antigcast</b></blockquote>"""

db = mongo_client["DOR"]
user_collection = db["user_dia"]
gc = db["listgrup"]
psnz = db["msg_text"]


async def get_user_ids(client_id):
    user_ids = await user_collection.find_one({"_id": client_id})
    return user_ids["user_dia"] if user_ids else []


async def get_blacklist_status(client_id):
    blacklist_status = await db.settings.find_one({"_id": client_id})
    return blacklist_status["status"] if blacklist_status else False


async def set_blacklist_status(client_id, status):
    await db.settings.update_one({"_id": client_id}, {"$set": {"status": status}}, upsert=True)


async def get_chat_ids(client_id):
    chat_ids = await gc.find_one({"_id": client_id})
    return chat_ids["grup"] if chat_ids else []


async def get_msg_ids(client_id):
    msg_ids = await psnz.find_one({"_id": client_id})
    return msg_ids["msg_text"] if msg_ids else []


async def purge(message):
    await asyncio.sleep(0.5)
    await message.delete()


def get_message(message):
    msg = (
        message.reply_to_message
        if message.reply_to_message
        else "" if len(message.command) < 2 else " ".join(message.command[1:])
    )
    return msg


def emoji(alias):
    emojis = {
        "bintang": "📚",
        "loading": "🌸",
        "proses": "❄",
        "gagal": "❌",
        "done": "✅",
        "upload": "♻️",
        "roses": "💬",
        "selesai": "❗",
        "on": "☁",
        "off": "⛔",
        "daftar": "📖",
    }
    return emojis.get(alias, "Emoji tidak ditemukan.")


Q = emoji("bintang")
gagal = emoji("gagal")
prs = emoji("proses")
batal = emoji("gagal")
rs = emoji("roses")
sls = emoji("selesai")
dn = emoji("done")
on = emoji("on")
off = emoji("off")
dftr = emoji("daftar")


@PY.UBOT("adduser")
@PY.TOP_CMD
async def add_user_to_blacklist(c, m):
    if len(m.command) != 2 and not m.reply_to_message:
        await m.reply_text(
            f"<b>__🌸 Gunakan Format: .adduser [id/reply]__</b> <b> ",
            quote=True,
        )
        return

    if m.reply_to_message:
        user_id = m.reply_to_message.from_user.id
    else:
        try:
            user_id = int(m.command[1])
        except ValueError:
            try:
                user = await c.get_users(m.command[1])
                user_id = user.id
            except Exception:
                await m.reply_text(f" <b>❗Tidak Bisa Menemukan Pengguna: {m.command[1]}</b>", quote=True)
                return

    user_ids = await get_user_ids(c.me.id)
    if user_id not in user_ids:
        user_ids.append(user_id)
        await user_collection.update_one({"_id": c.me.id}, {"$set": {"user_dia": user_ids}}, upsert=True)
        await m.reply_text(f"<b>❗Pengguna: {user_id} Berhasil Di Tambahkan Ke Dalam DataBase</b>", quote=True)
    else:
        await m.reply_text(f"<b>⚠️Pengguna Tersebut Sudah Di Dalam DataBase<b> ", quote=True)


@PY.UBOT("listuser")
@PY.TOP_CMD
async def display_blacklist(client, message):
    user_ids = await get_user_ids(client.me.id)
    await message.reply_text(f"<b>📝 Result:</b>\n<b>• {user_ids}</b>\n", quote=True)


@PY.UBOT("unadduser")
@PY.TOP_CMD
async def remove_user_from_blacklist(c, m):
    if len(m.command) != 2 and not m.reply_to_message:
        await m.reply_text(
            f"<b>__🌸 Gunakan Format: .unadduser [id/reply]__</b>",
            quote=True,
        )
        return

    if m.reply_to_message:
        user_id = m.reply_to_message.from_user.id
    else:
        user_id = int(m.command[1])

    user_ids = await get_user_ids(c.me.id)
    if user_id in user_ids:
        user_ids.remove(user_id)
        await user_collection.update_one({"_id": c.me.id}, {"$set": {"user_dia": user_ids}}, upsert=True)
        await m.reply_text(f"<b>❗Pengguna: {user_id} Berhasil Di Hapus Dari Dalam DataBase</b>", quote=True)
    else:
        await m.reply_text(f"<b>⚠️Pengguna Tersebut Tidak Dalam DataBase<b>", quote=True)


@PY.UBOT("cekatgs")
@PY.TOP_CMD
async def checkstatus(client, message):
    cek = await get_blacklist_status(client.me.id)
    if cek:
        await message.reply_text(f"<b>✨ Anda Sudah Mengaktifkan AntiGcast</b>", quote=True)
    else:
        await message.reply_text(f"<b>❗ Anda Belum Mengaktifkan AntiGcast</b>", quote=True)


@PY.UBOT("on")
@PY.TOP_CMD
async def enable_blacklist(c, m):
    await set_blacklist_status(c.me.id, True)
    await m.reply_text(f"<b>👉 Antigcast Berhasil Di Aktifkan</b>", quote=True)


@PY.UBOT("off")
@PY.TOP_CMD
async def disable_blacklist(c, m):
    await set_blacklist_status(c.me.id, False)
    await m.reply_text(f"<b>✨ Antigcast Berhasil Di Matikan</b> ", quote=True)


@PY.UBOT("addgroup")
@PY.TOP_CMD
async def add_group_to_antigcast(c, m):
    type = (ChatType.GROUP, ChatType.SUPERGROUP)

    if m.chat.type not in type:
        await m.reply_text(f"<b>📛 Khusus Untuk Group</b>")
        return

    user_id = m.chat.id
    chat_ids = await get_chat_ids(c.me.id)
    if user_id not in chat_ids:
        chat_ids.append(user_id)
        await gc.update_one({"_id": c.me.id}, {"$set": {"grup": chat_ids}}, upsert=True)
        await m.reply_text(f"<b>👉 ID Group: {user_id} Telah Ditambahkan Ke Daftar Antigcast</b>", quote=True)
    else:
        await m.reply_text(f"<b>❗Grup Tersebut Sudah Ada Dalam Daftar Antigcast<b> ", quote=True)


@PY.UBOT("deletegroup")
@PY.TOP_CMD
async def remove_group_from_antigcast(c, m):
    type = (ChatType.GROUP, ChatType.SUPERGROUP)
    if m.chat.type not in type:
        await m.reply_text(f"<b>🌸 Gunakan Fitur Ini Di Grup Atau Berikan Id Grup</b>", quote=True)
        return

    chat_id = None
    if len(m.command) >= 2:
        try:
            chat_id = int(m.command[1])
        except ValueError:
            await m.reply_text(f" ID grup tidak valid", quote=True)
            return

    if not chat_id:
        chat_id = m.chat.id

    chat_ids = await get_chat_ids(c.me.id)
    if chat_id in chat_ids:
        chat_ids.remove(chat_id)
        await gc.update_one({"_id": c.me.id}, {"$set": {"grup": chat_ids}}, upsert=True)
        await m.reply_text(f"<b>👉 ID-Group: {chat_id} Telah Dihapus Dari Daftar Antigcast</b>", quote=True)
    else:
        await m.reply_text(f"<b>✨ ID-Group: {chat_id} Tidak Ada Di Dalam DataBase Antigcast</b> ", quote=True)


@PY.UBOT("listgc|listgroup")
@PY.TOP_CMD
async def display_antigcast(c, m):
    user_ids = await get_chat_ids(c.me.id)
    await m.reply_text(f"<b>❗List Group Blacklist-Text: {user_ids}</b> \n", quote=True)


@PY.UBOT("addmsg")
@PY.TOP_CMD
async def add_pesan(c, m):
    _rply = m.reply_to_message
    if not _rply:
        await m.reply(f"<b>__🌸 Gunakan Format: .addmsg [reply]__</b>")
        return
    user_text = _rply.text
    msg_ids = await get_msg_ids(c.me.id)
    if user_text not in msg_ids:
        msg_ids.append(user_text)
        await psnz.update_one({"_id": c.me.id}, {"$set": {"msg_text": msg_ids}}, upsert=True)
        sukses = await m.reply_text(f"<b>📖 Berhasil Di Tambahkan Ke Dalam Bl-Text</b>", quote=True)
        await _rply.delete()
        await purge(m)
        await sukses.delete()
    else:
        x = await m.reply_text(f"<b>✨ Pesan Sudah Dalam DataBase Bl-Text</b>", quote=True)
        await asyncio.sleep(0.5)
        await x.delete()


@PY.UBOT("listmsg")
@PY.TOP_CMD
async def strdb(client, message):
    pesan = await get_msg_ids(client.me.id)
    try:
        await message.reply_text(pesan)
    except MessageTooLong:
        with open("db.txt", "a", encoding="utf-8") as file:
            file.write(f"{pesan}\n")
        kirim = await message.reply_document(db.txt)
        if kirim:
            os.remove("db.txt")


@PY.UBOT("deletemsg")
@PY.TOP_CMD
async def remove_kata_from_blacklist(c, m):
    if len(m.command) != 2 and not m.reply_to_message:
        await m.reply_text(
            f"<b>🌸 Penggunaan</b>\n\n<b>📚 .deletemsg [Reply/Text]</b>",
            quote=True,
        )
        return

    if m.reply_to_message:
        user_id = m.reply_to_message.text
    else:
        user_id = " ".join(m.command[1:])

    user_ids = await get_msg_ids(c.me.id)
    if user_id in user_ids:
        user_ids.remove(user_id)
        await psnz.update_one({"_id": c.me.id}, {"$set": {"msg_text": user_ids}}, upsert=True)
        await m.reply_text(f"<b>❗Terhapus: {user_id} Berhasil Terhapus Dari Daftar Bl-Text</b>", quote=True)
    else:
        await m.reply_text(f"<b>📛 Kata Tersebut Tidak Dalam Daftar Bl-Text</b>", quote=True)


@ubot.on_message(filters.group & ~filters.me, group=75)
async def delete_messages(client, message):
    try:
        chat_ids = await get_chat_ids(client.me.id)
        if message.chat.id not in chat_ids:
            return

        blacklist_status = await get_blacklist_status(client.me.id)
        if not blacklist_status:
            return

        user_ids = await get_user_ids(client.me.id)
        user_msg_patterns = await get_msg_ids(client.me.id)

        if message.from_user.id in user_ids:
            return await message.delete()
        else:
            for pattern in user_msg_patterns:
                if bool(re.search(pattern, message.text)):
                    await message.delete()
                    return await message.delete()
    except Exception:
        pass
