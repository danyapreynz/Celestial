import requests
from PyroUbot import *

__MODULE__ = "shio"
__HELP__ = f"""📖 <u><b>Folder Module Shio</b></u>>

<blockquote><b>📚 perintah: .shio [ɴᴀᴍᴀ][ᴛᴀɴɢɢᴀʟ][ʙᴜʟᴀɴ][ᴛᴀʜᴜɴ]</b>
<b>📝 penjelasan: untuk mengetahui ramalan dari shio</b></blockquote>"""


@PY.UBOT("shio")
async def get_shio(client, message):
    args = message.text.split()
    if len(args) < 5:
        return await message.reply_text("<b>📚 Gunakan Format:</b>\n<b>🌸 .shio [ɴᴀᴍᴀ][ᴛᴀɴɢɢᴀʟ][ʙᴜʟᴀɴ][ᴛᴀʜᴜɴ]</b>")

    shio, tanggal, bulan, tahun = args[1], args[2], args[3], args[4]
    API_URL = f"https://api.botcahx.eu.org/api/primbon/shio?shio={shio}&tanggal={tanggal}&bulan={bulan}&tahun={tahun}&apikey=VENOZY"

    try:
        response = requests.get(API_URL)
        data = response.json()

        if not data.get("status") or not data["result"].get("status"):
            return await message.reply_text("⚠️ Data tidak ditemukan atau terjadi kesalahan.")

        result = data["result"]["message"]
        nama = result["nama"]
        arti = result["arti"]

        reply_text = (
            f"🔮 **Ramalan Shio** \n"
            f"<blockquote>🪪 <b>shio: {nama}</b>\n"
            f"📅 <b>tanggal: {tanggal}-{bulan}-{tahun}</b>\n"
            f"<b>=======================</b>\n"
            f"📝 <b>Arti:</b>{arti}</blockquote>"
        )

        await message.reply_text(reply_text, disable_web_page_preview=True)

    except Exception as e:
        await message.reply_text(f"⚠️ Terjadi kesalahan: `{e}`")
