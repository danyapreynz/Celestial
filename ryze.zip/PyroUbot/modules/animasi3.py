__MODULE__ = "animasi4"
__HELP__ =  """📖 <u><b>Folder Module Animasi4</b></u>

<blockquote><b>📚 perintah: .nah or.tembak</b>
<b>📝 penjelasan: untuk memunculkan animasi nah / tembak</b></blockquote>
<blockquote><b>📚 perintah: .piss or .yatim</b>
<b>📝 penjelasan: untuk memunculkan animasi pis / yatim</b></blockquote>
<blockquote><b>📚 perintah: .kuda or .love</b>
<b>📝 penjelasan: untuk memunculkan animasi kuda / love</b></blockquote>
<blockquote><b>📚 perintah: .okay or .wow</b>
<b>📝 penjelasan: untuk memunculkan animasi okay / wow</b></blockquote>
<blockquote><b>📚 perintah: .yatim or .kokkelas</b>
<b>📝 penjelasan: untuk memunculkan animasi yatim / kokkelas</b></blockquote>
<blockquote><b>📚 perintah: .asu or .jawa 
<b>📝 penjelasan: untuk memunculkan animasi asu / jawa</b></blockquote>
<blockquote><b>📚 perintah: .y or .sunda
<b>📝 penjelasan: untuk memunculkan animasi y / sunda</b></blockquote>"""
