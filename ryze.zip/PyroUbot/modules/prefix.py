__MODULE__ = "prefixes"
__HELP__ = """📖 <u><b>Folder Module Prefixes</b></u>

<blockquote><b>📚 perintah: .prefix [sʏᴍʙᴏʟ/ᴛᴇxᴛ]</b>
<b>📝 penjelasan: untuk mengubah awal command</b></blockquote>"""