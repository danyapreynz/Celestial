__MODULE__ = "group"
__HELP__ = """📖 <u><b>Folder Module Group</b></u>

<blockquote><b>📚 perintah: .etmin</b>
<b>📝 penjelasan: untuk mengadminkan user</b></blockquote>
<blockquote><b>📚 perintah: .demote</b>
<b>📝 penjelasan: untuk mengunadmin user</b></blockquote>
<blockquote><b>📚 perintah: .ceo</b>
<b>📝 penjelasan: untuk menjadikan owner</b></blockquote>
<blockquote><b>📚 perintah: .getlink</b>
<b>📝 penjelasan: untuk mengambil link group</b></blockquote>"""