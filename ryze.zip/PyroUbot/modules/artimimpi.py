__MODULE__ = "artimimpi"
__HELP__ =  """📖 <u><b>Folder Module ArtiMimpi</b></u>

<blockquote><b>📚 perintah: .artimimpi [ᴍɪᴍᴘɪ]</b>
<b>📝 penjelasan: untuk mencari arti mimpi tersebut</b></blockquote>"""
