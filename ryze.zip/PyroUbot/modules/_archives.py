from PyroUbot.core.helpers.tools import get_data_id
from PyroUbot import *
__MODULE__ = "archive"
__HELP__ =  """📖 <u><b>Folder Module Archive</b></u>

<blockquote><b>📚 perintah: .arch</b>
<b>📝 penjelasan: untuk archive chat group/channel/probadi</b></blockquote>
<blockquote><b>📚 perintah: .unarch</b>
<b>📝 penjelasan: untuk unarchive chat group/channel/probadi</b></blockquote>"""

@PY.UBOT("arch")
@PY.TOP_CMD
async def archive_user(client, message):
    prs = await EMO.PROSES(client)
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    if len(message.command) <2:
        return await message.reply(f"<b> Gunakan Perintah: arch [group/users/all]</b>")
    anjai = await message.reply(f"<b>💬 was running wait a minute. ✨</b>")
    anjir = message.command[1]
    xx = await get_data_id(client, anjir)
    for anu in xx:
        await client.archive_chats(anu)
    
    await anjai.edit(f"<b>__✨ Berhasil Mengarchivekan Semua Chat {anjir}__</b>")

@PY.UBOT("unarch")
@PY.TOP_CMD
async def unarchive_user(client, message):
    prs = await EMO.PROSES(client)
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    if len(message.command) <2:
        return await message.reply(f"<b> Gunakan Perintah: unarch [group/users/all]</b>")
    anjai = await message.reply(f"<b>💬 was running wait a minute. ✨</b>")
    anjir = message.command[1]
    xx = await get_data_id(client, anjir)
    for anu in xx:
        await client.unarchive_chats(anu)
    await anjai.edit(f"<b>__✨ Berhasil Mengunarchivekan Semua Chat {anjir}__</b>")
