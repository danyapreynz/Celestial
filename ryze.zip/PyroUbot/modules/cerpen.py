import requests
from pyrogram import Client, filters
from PyroUbot import *

__MODULE__ = "cerpen"
__HELP__ =  """📖 <u><b>Folder Module Cerpen</b></u>

<blockquote><b>📚 perintah: .cerpen [ᴛʏᴘᴇ]</b>
<b>📝 penjelasan: untuk mencari sebuah cerita pendek</b></blockquote>
<blockquote><b>📃 Type:</b>
   <b>remaja</b>
   <b>anak</b>
   <b>misteri</b>
   <b>cinta</b>
   <b>romantis</b>
   <b>galau</b>
   <b>budaya</b>
   <b>gokil</b>
   <b>inspiratif</b>
   <b>kehidupan</b>
   <b>sastra</b>
   <b>jepang</b>
   <b>ᴋᴏʀᴇᴀ</b>
   <b>keluarga</b>
   <b>oersahabatan</b>
   <b>kristen</b>
   <b>ramadhan</b>
   <b>liburan</b>
   <b>lingkungan</b>
   <b>nasihat</b>
   <b>motivasi</b>
   <b>pendidikan</b>
   <b>petualangan</b>
   <b>mengharukan</b></blockquote>"""

@PY.UBOT("cerpen")
async def _(client, message):
    if len(message.command) < 2:
        await message.reply_text("<b> ɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ: .cerpen [ᴛʏᴘᴇ]</b>")
        return
    
    tt = " ".join(message.command[1:])
    url = f"https://api.botcahx.eu.org/api/story/cerpen?type={tt}&apikey=VENOZY"
    
    await message.reply_text("<b>💬 was running wait a minute. ✨</b>")
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if data["status"]:
            await message.reply_text(f"""<blockquote>📖 cerita:{data['result']['title']}

{data['result']['cerita']}</blockquote>""")
        else:
            await message.reply_text("eror")
    else:
        await message.reply_text("eror")
