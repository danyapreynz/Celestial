from datetime import datetime, timedelta

from dateutil.relativedelta import relativedelta
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pytz import timezone


from PyroUbot import *


__MODULE__ = "db control"
__HELP__ = """📖 <u><b>Folder Module Db Control</b></u>

<blockquote><b>📚 perintah: .time</b>
<b>📝 penjelasan: untuk mengatur waktu pengguna</b></blockquote>
<blockquote><b>📚 perintah: .cek</b>
<b>📝 penjelasan: untuk cek masa aktif pengguna userbot</b></blockquote>
<blockquote><b>📚 perintah: .cping</b>
<b>📝 penjelasan: untuk mencaritahu cek kecepatan ping</b></blockquote>
<blockquote><b>📚 perintah: .caddbl</b>
<b>📝 penjelasan: untuk mencaritahu cek status blacklist</b></blockquote>
<blockquote><b>📚 perintah: .calive</b>
<b>📝 penjelasan: untuk mencaritahu cek status alive</b></blockquote>
<blockquote><b>📚 perintah: .climit</b>
<b>📝 penjelasan: untuk mencaritahu cek status limit</b></blockquote>"""

@PY.BOT("addadmbc")
@PY.OWNER
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    user_id = await extract_user(message)
    if not user_id:
        return await msg.edit(
            f"{message.text} [id/username]"
        )

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)

    admin_users = await get_list_from_vars(client.me.id, "ADMBC_USERS")

    if user.id in admin_users:
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Sudah Dalam Daftar</b>
"""
        )

    try:
        await add_to_vars(client.me.id, "ADMBC_USERS", user.id)
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Berhasil Di Tambahkan</b>
"""
        )
    except Exception as error:
        return await msg.edit(error)

@PY.BOT("unadmbc")
@PY.OWNER
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    user_id = await extract_user(message)
    if not user_id:
        return await msg.edit(
            f"{message.text} [username/id]"
        )

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)

    adminbc_users = await get_list_from_vars(client.me.id, "ADMBC_USERS")

    if user.id not in adminbc_users:
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Tidak Dalam Daftar</b>
"""
        )

    try:
        await remove_from_vars(client.me.id, "ADMBC_USERS", user.id)
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Terhapus</b>
"""
        )
    except Exception as error:
        return await msg.edit(error)


@PY.BOT("getadmbc")
@PY.ADMBC
async def _(client, message):
    Sh = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    adminbc_users = await get_list_from_vars(client.me.id, "ADMBC_USERS")

    if not adminbc_users:
        return await Sh.edit("<b>❕Daftar Admin Bc Kosong</b>")

    admin_list = []
    for user_id in adminbc_users:
        try:
            user = await client.get_users(int(user_id))
            admin_list.append(
                f"👤 [{user.first_name} {user.last_name or ''}](tg://user?id={user.id}) | {user.id}"
            )
        except:
            continue

    if admin_list:
        response = (
            "<b>🌸 daftar admin:\n\n"
            + "\n".join(admin_list)
            + f"\n<b>👉 Total Admin: {len(admin_list)}</b>"
        )
        return await Sh.edit(response)
    else:
        return await Sh.edit("<b>‼️ Tidak Dapat Mengambil Data Admin</b>")

@PY.BOT("prem")
@PY.SELLER
async def _(client, message):
    user_id, get_bulan = await extract_user_and_reason(message)
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    if not user_id:
        return await msg.edit(f"<b>{message.text} id/username </b>")

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)
    if not get_bulan:
        get_bulan = 1

    prem_users = await get_list_from_vars(client.me.id, "PREM_USERS")

    if user.id in prem_users:
        return await msg.edit(f"""
<b>👉 Status Akun</b>
<b>✨ ID Users: {user.id}</b>
<b>⏱️ Expired: {get_bulan} ʙᴜʟᴀɴ</b>
<b>📝 Sudah Dalam DataBase Premium</ci></b>
"""
        )

    try:
        now = datetime.now(timezone("Asia/Jakarta"))
        expired = now + relativedelta(months=int(get_bulan))
        await set_expired_date(user_id, expired)
        await add_to_vars(client.me.id, "PREM_USERS", user.id)
        await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>🤖 Userbot: @Ryzesxx_bot</b>
<b>⏱️ Expired Users: {get_bulan} bulan</b>
<b>📚 Status: Berhasil Di Tambahkan</b>"""
        )
        return await bot.send_message(
            OWNER_ID,
            f"add: {message.from_user.id}\nᴄᴏsᴛᴜᴍᴇʀ ɪᴅ: {user_id}",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "seles/admin",
                            callback_data=f"profil {message.from_user.id}",
                        ),
                        InlineKeyboardButton(
                            "pengguna", callback_data=f"profil {user_id}"
                        ),
                    ],
                ]
            ),
        )
    except Exception as error:
        return await msg.edit(error)


@PY.BOT("unprem")
@PY.SELLER
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    user_id = await extract_user(message)
    if not user_id:
        return await msg.edit(
            f"<b>{message.text} [username/id]</b>"
        )

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)

    prem_users = await get_list_from_vars(client.me.id, "PREM_USERS")

    if user.id not in prem_users:
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Tidak Dalam Daftar</b>
 """
        )
    try:
        await remove_from_vars(client.me.id, "PREM_USERS", user.id)
        await rem_expired_date(user_id)
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Berhasil Terhapus</b>
"""
        )
    except Exception as error:
        return await msg.edit(error)
        

@PY.BOT("getprem")
@PY.SELLER
async def _(client, message):
    text = ""
    count = 0
    prem = await get_list_from_vars(client.me.id, "PREM_USERS")
    prem_users = []

    for user_id in prem:
        try:
            user = await bot.get_users(user_id)
            count += 1
            userlist = f"• {count}: <a href=tg://user?id={user.id}>{user.first_name} {user.last_name or ''}</a> > <code>{user.id}"
        except Exception:
            continue
        text += f"<b>{userlist}\n</b>"
    if not text:
        await message.reply_text("ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴘᴇɴɢɢᴜɴᴀ ʏᴀɴɢ ᴅɪᴛᴇᴍᴜᴋᴀɴ")
    else:
        await message.reply_text(text)


@PY.BOT("seles")
@PY.ADMIN
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    user_id = await extract_user(message)
    if not user_id:
        return await msg.edit(
            f"<b>{message.text} [username/id]</b>"
        )

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)

    sudo_users = await get_list_from_vars(client.me.id, "SELER_USERS")

    if user.id in sudo_users:
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Sudah Dalam Daftar</b>
"""
        )

    try:
        await add_to_vars(client.me.id, "SELER_USERS", user.id)
        return await msg.edit(f"""
 <b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Berhasil Di Tambahkan</b>
"""
        )
    except Exception as error:
        return await msg.edit(error)


@PY.BOT("unseles")
@PY.ADMIN
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    user_id = await extract_user(message)
    if not user_id:
        return await msg.edit(
            f"<b>{message.text} [username/id]</b>"
        )

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)

    seles_users = await get_list_from_vars(client.me.id, "SELER_USERS")

    if user.id not in seles_users:
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Tidak Dalam Daftar</b>
"""
        )

    try:
        await remove_from_vars(client.me.id, "SELER_USERS", user.id)
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Berhasil Terhapus</b>
"""
        )
    except Exception as error:
        return await msg.edit(error)


@PY.BOT("getseles")
@PY.ADMIN
async def _(client, message):
    Sh = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    seles_users = await get_list_from_vars(client.me.id, "SELER_USERS")

    if not seles_users:
        return await Sh.edit("daftar seller kosong")

    seles_list = []
    for user_id in seles_users:
        try:
            user = await client.get_users(int(user_id))
            seles_list.append(
                f"<b>👤 [{user.first_name} {user.last_name or ''}](tg://user?id={user.id}) | <code>{user.id}</b>"
            )
        except:
            continue

    if seles_list:
        response = (
            "📋 ᴅᴀғᴛᴀʀ sᴇʟʟᴇʀ:\n\n"
            + "\n".join(seles_list)
            + f"\n.ᴛᴏᴛᴀʟ ʀᴇsᴇʟʟᴇʀ : {len(seles_list)}"
        )
        return await Sh.edit(response)
    else:
        return await Sh.edit("ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢᴀᴍʙɪʟ ᴅᴀғᴛᴀʀ sᴇʟʟᴇʀ")


@PY.BOT("time")
@PY.SELLER
@PY.ADMIN
async def _(client, message):
    Tm = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    bajingan = message.command
    if len(bajingan) != 3:
        return await Tm.edit(f"mohon gunakan /time user_id hari")
    user_id = int(bajingan[1])
    get_day = int(bajingan[2])
    print(user_id , get_day)
    try:
        get_id = (await client.get_users(user_id)).id
        user = await client.get_users(user_id)
    except Exception as error:
        return await Tm.edit(error)
    if not get_day:
        get_day = 30
    now = datetime.now(timezone("Asia/Jakarta"))
    expire_date = now + timedelta(days=int(get_day))
    await set_expired_date(user_id, expire_date)
    await Tm.edit(f"""
ɪɴғᴏʀᴍᴀᴛɪᴏɴ :

 ɴᴀᴍᴇ: {user.mention}
 ᴜsᴇɪᴅ: {get_id}
 ᴀᴋᴛɪғ: {get_day} ʜᴀʀɪ
"""
    )


@PY.BOT("cek")
@PY.SELLER
@PY.ADMIN
async def _(client, message):
    Sh = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    user_id = await extract_user(message)
    if not user_id:
        return await Sh.edit("pengguna tidak temukan")
    try:
        get_exp = await get_expired_date(user_id)
        sh = await client.get_users(user_id)
    except Exception as error:
        return await Sh.ediit(error)
    if get_exp is None:
        await Sh.edit(f"""
ɪɴғᴏʀᴍᴀᴛɪᴏɴ :

 ɴᴀᴍᴇ: {sh.mention}
 ᴘʟᴀɴ: ɴᴏɴᴇ
 ᴜsᴇɪᴅ: {user_id}
 ᴘʀᴇғɪx : .
 ᴇxᴘɪʀᴇᴅ : ɴᴏɴᴀᴋᴛɪғ
""")
    else:
        SH = await ubot.get_prefix(user_id)
        exp = get_exp.strftime("%d:%m:%Y")
        if user_id in await get_list_from_vars(client.me.id, "ULTRA_PREM"):
            status = "SuperUltra"
        else:
            status = "Premium"
        await Sh.edit(f"""
ɪɴғᴏʀᴍᴀᴛɪᴏɴ :

 ɴᴀᴍᴇ: {sh.mention}
 ᴘʟᴀɴ: {status}
 ᴜsᴇɪᴅ: {user_id}
 ᴘʀᴇғɪx: {' '.join(SH)}
 ᴇxᴘɪʀᴇᴅ: {exp}
"""
        )

@PY.BOT("addadmin")
@PY.OWNER
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    user_id = await extract_user(message)
    if not user_id:
        return await msg.edit(
            f"{message.text} [username/id]"
        )

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)

    admin_users = await get_list_from_vars(client.me.id, "ADMIN_USERS")

    if user.id in admin_users:
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Sudah Dalam Daftar</b>
"""
        )

    try:
        await add_to_vars(client.me.id, "ADMIN_USERS", user.id)
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Berhasil Di Tambahkan</b>
"""
        )
    except Exception as error:
        return await msg.edit(error)


@PY.BOT("unadmin")
@PY.OWNER
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    user_id = await extract_user(message)
    if not user_id:
        return await msg.edit(
            f"{message.text} [username/id]"
        )

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)

    admin_users = await get_list_from_vars(client.me.id, "ADMIN_USERS")

    if user.id not in admin_users:
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Tidak Dalam Daftar</b>
"""
        )

    try:
        await remove_from_vars(client.me.id, "ADMIN_USERS", user.id)
        return await msg.edit(f"""
<b>👉 Pengguna:</b>
<b>🪪 Name Users: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})</b>
<b>✨ ID -Users: {user.id}</b>
<b>📚 Status: Berhasil Terhapus</b>
"""
        )
    except Exception as error:
        return await msg.edit(error)


@PY.BOT("getadmin")
@PY.OWNER
async def _(client, message):
    Sh = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    admin_users = await get_list_from_vars(client.me.id, "ADMIN_USERS")

    if not admin_users:
        return await Sh.edit("<s>daftar admin kosong</s>")

    admin_list = []
    for user_id in admin_users:
        try:
            user = await client.get_users(int(user_id))
            admin_list.append(
                f"👤 [{user.first_name} {user.last_name or ''}](tg://user?id={user.id}) | {user.id}"
            )
        except:
            continue

    if admin_list:
        response = (
            "📋 daftar admin:\n\n"
            + "\n".join(admin_list)
            + f"\n.ᴛᴏᴛᴀʟ ᴀᴅᴍɪɴ: {len(admin_list)}"
        )
        return await Sh.edit(response)
    else:
        return await Sh.edit("ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢᴀᴍʙɪʟ ᴅᴀғᴛᴀʀ ᴀᴅᴍɪɴ")

@PY.BOT("superultra")
@PY.SELLER
@PY.ADMIN
async def _(client, message):
    user_id, get_bulan = await extract_user_and_reason(message)
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    if not user_id:
        return await msg.edit(f"{message.text} [username/id]")

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)
    if not get_bulan:
        get_bulan = 1

    prem_users = await get_list_from_vars(client.me.id, "ULTRA_PREM")

    if user.id in prem_users:
        return await msg.edit(f"""
ɴᴀᴍᴇ: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})
ᴜsᴇɪᴅ: {user.id}
ᴋᴇᴛᴇʀᴀɴɢᴀɴ: sᴜᴅᴀʜ <code>[SuperUltra]
ᴇxᴘɪʀᴇᴅ: <code>{get_bulan} ʙᴜʟᴀɴ
"""
        )

    try:
        now = datetime.now(timezone("Asia/Jakarta"))
        expired = now + relativedelta(months=int(get_bulan))
        await set_expired_date(user_id, expired)
        await add_to_vars(client.me.id, "ULTRA_PREM", user.id)
        await msg.edit(f"""
ɴᴀᴍᴇ: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})
ᴜsᴇɪᴅ: <code>{user.id}
ᴇxᴘɪʀᴇᴅ: <code>{get_bulan} ʙᴜʟᴀɴ
ꜱɪʟᴀʜᴋᴀɴ ʙᴜᴋᴀ: @{client.me.mention} ᴜɴᴛᴜᴋ ᴍᴇᴍʙᴜᴀᴛ ᴜꜱᴇʀʙᴏᴛ
sᴛᴀᴛᴜs: <code>[SuperUltra]
"""
        )
        return await bot.send_message(
            OWNER_ID,
            f"sᴇʟʟᴇʀ ɪᴅ: {message.from_user.id}\nᴄᴜsᴛᴏᴍᴇʀ ɪᴅ: {user_id}",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "sᴇʟʟᴇʀ ɪᴅ",
                            callback_data=f"profil {message.from_user.id}",
                        ),
                        InlineKeyboardButton(
                            "ᴄᴏsᴛᴜᴍᴇʀ ɪᴅ", callback_data=f"profil {user_id}"
                        ),
                    ],
                ]
            ),
        )
    except Exception as error:
        return await msg.edit(error)

@PY.BOT("rmultra")
@PY.SELLER
@PY.ADMIN
async def _(client, message):
    msg = await message.reply("<b>💬 was running wait a minute. ✨</b><")
    user_id = await extract_user(message)
    if not user_id:
        return await msg.edit(
            f"{message.text} [username/id]"
        )

    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await msg.edit(error)

    prem_users = await get_list_from_vars(client.me.id, "ULTRA_PREM")

    if user.id not in prem_users:
        return await msg.edit(f"""
name: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})
ᴜsᴇɪᴅ: <code>{user.id}
ᴋᴇᴛᴇʀᴀɴɢᴀɴ: ᴛɪᴅᴀᴋ ᴅᴀʟᴀᴍ ᴅᴀғᴛᴀʀ
"""
        )
    try:
        await remove_from_vars(client.me.id, "ULTRA_PREM", user.id)
        await rem_expired_date(user_id)
        return await msg.edit(f"""
name: [{user.first_name} {user.last_name or ''}](tg://user?id={user.id})
ᴜsᴇɪᴅ: {user.id}
ᴋᴇᴛᴇʀᴀɴɢᴀɴ: ɴᴏɴᴇ sᴜᴘᴇʀᴜʟᴛʀᴀ
"""
        )
    except Exception as error:
        return await msg.edit(error)
        

@PY.BOT("getultra")
@PY.SELLER
@PY.ADMIN
async def _(client, message):
    prem = await get_list_from_vars(client.me.id, "ULTRA_PREM")
    prem_users = []

    for user_id in prem:
        try:
            user = await client.get_users(user_id)
            prem_users.append(
                f"👤 [{user.first_name} {user.last_name or ''}](tg://user?id={user.id}) | {user.id}"
            )
        except Exception as error:
            return await message.reply(str(error))

    total_prem_users = len(prem_users)
    if prem_users:
        prem_list_text = "\n".join(prem_users)
        return await message.reply(
            f"📋 daftar superultra:\n\n{prem_list_text}\nᴛᴏᴛᴀʟ sᴜᴘᴇʀᴜʟᴛʀᴀ: {total_prem_users}"
        )
    else:
        return await message.reply("ᴛɪᴅᴀᴋ ᴀᴅᴀ sᴜᴘᴇʀᴜʟᴛʀᴀ sᴀᴀᴛ ɪɴɪ")
