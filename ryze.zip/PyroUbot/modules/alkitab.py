__MODULE__ = "alkitab"
__HELP__ =  """📖 <u><b>Folder Module Alkitab</b></u>

<blockquote><b>📚 perintah: .kitab [ᴋᴇᴊᴀᴅɪᴀɴ]</b>
<b>📝 penjelasan: untuk mencari kejadian di alkitab</b></blockquote>"""
