__MODULE__ = "tts"
__HELP__ =  """📖 <u><b>Folder Module Tts</b></u>

<blockquote><b>📚 perintah: .tts [text]</b>
<b>📝 penjelasan: untuk membuat text menjadi audio</b></blockquote>"""
