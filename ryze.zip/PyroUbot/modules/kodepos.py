from pyrogram import Client, filters
import requests
import io
from PyroUbot import *


__MODULE__ = "kode pos"
__HELP__ = """📖 <u><b>Folder Module Kode Pos</b></u>

<blockquote><b>📚 perintah: .kdps [nama kota]</b>
<b>📝 penjelasan: untuk mencari kode post di suatu kota</b></blockquote>"""


@PY.UBOT("kdps")
async def get_postal_code(client, message):
    if len(message.command) < 2:
        return await message.reply("gunakan perintah: .kodepos [nama kota]")
    
    query = message.text.split(None, 1)[1]
    url = f"https://api.botcahx.eu.org/api/search/kodepos?query={query}&apikey=VENOZY"
    
    process_msg = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    
    response = requests.get(url)
    if response.status_code != 200:
        await process_msg.delete()
        return await message.reply("gagal mengambil data kode pos.")
    
    data = response.json()
    
    if not data.get("status") or not data.get("result"):
        await process_msg.delete()
        return await message.reply("kode pos tidak ditemukan.")
    
    result_text = "\n".join([
        f"provinsi: {item['province']}\n"
        f"kota: {item['city']}\n"
        f"kecamatan: {item['district']}\n"
        f"desa: {item['village']}\n"
        f"kode pos: {item['postalCode']}\n"
        for item in data["result"]
    ])
    
    if len(result_text) > 4000:
        file = io.BytesIO(result_text.encode("utf-8"))
        file.name = f"kode pos {query}.txt"
        await message.reply_document(file)
    else:
        await message.reply(result_text)

    await process_msg.delete()
