__MODULE__ = "bl users"
__HELP__ =  """📖 <u><b>Folder Module Bl Users</b></u>

<blockquote><b>📚 perintah: .listuser</b>
<b>📝 penjelasan: untuk melihat daftar pengguna blacklist users</b></blockquote>
<blockquote><b>📚 perintah: .adduser</b>
<b>📝 penjelasan: untuk menambahkan pengguna ke dalam list bl users</b></blockquote>
<blockquote><b>📚 perintah: .unadduser</b>
<b>📝 penjelasan: untuk menghapus pengguna dari dalam list bl users</b></blockquote>"""
