__MODULE__ = "afk"
__HELP__ =  """📖 <u><b>Folder Module Afk</b></u>

<blockquote><b>📚 perintah: .afk [ᴀʟᴀsᴀɴ]</b>
<b>📝 penjelasan: untuk mengaktifkan afk</b></blockquote>
<blockquote><b>📚 perintah: .unafk</b>
<b>📝 penjelasan: untuk menonaktifkan afk</b></blockquote>"""
