import asyncio
import datetime
import pytz
from datetime import datetime
from PyroUbot import *

__MODULE__ = "done"
__HELP__ = """📖 <u><b>Folder Module Done</b></u>

<blockquote><b>📚 perintah: .done [ʙᴀʀᴀɴɢ][ʜᴀʀɢᴀ][ᴛᴏᴛᴀʟ ʙᴀʏᴀʀ]</b>
<b>📝 penjelasan: untuk membuat konfirmasi pembayaran</b>"""


@PY.UBOT("done|dn")
async def done_command(client, message):
    izzy_ganteng = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    await asyncio.sleep(1)
    try:
        args = message.text.split(" ", 1)
        if len(args) < 2 or "," not in args[1]:
            await message.reply_text("<b>ᴘᴇʀɪɴᴛᴀʜ .done [ʙᴀʀᴀɴɢ][ʜᴀʀɢᴀ][ᴛᴏᴛᴀʟ ʙᴀʏᴀʀ]</b>\n<b>ᴄᴏɴᴛᴏʜ: .done USERBOT,10.000,-00,10.200,-00</b>")
            return

        parts = args[1].split(",", 2)

        if len(parts) < 2:
            await message.reply_text("<b>ᴘᴇʀɪɴᴛᴀʜ .done [ʙᴀʀᴀɴɢ][ʜᴀʀɢᴀ][ᴛᴏᴛᴀʟ ʙᴀʏᴀʀ]</b>\n<b>ᴄᴏɴᴛᴏʜ: .done USERBOT,10.000,-00,10.200,-00</b>")
            return

        name_item = parts[0].strip()
        price = parts[1].strip()
        totalprice = parts[2].strip() if len(parts) > 2 else "lainnya"
        time = datetime.now(pytz.timezone('asia/Jakarta')).strftime("%d/%m/%Y")
        jam = datetime.now(pytz.timezone('asia/Jakarta')).strftime("%H:%M:%S")
        response = (
f"```SUCCESSFULLY TRANSACTION\n"
f"﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉\n"
f"• NAMA BARANG : {name_item}\n"
f"• HARGA BARANG : {price}\n"
f"• TOTAL HARGA : {totalprice}\n"
f"• JAM TRANSAKSI : {jam}\n"
f"• TANGGAL : {time}\n"
f"﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉```\n"
        )
        await izzy_ganteng.edit(response)

    except Exception as e:
        await izzy_ganteng.edit(f"error: {e}")
        