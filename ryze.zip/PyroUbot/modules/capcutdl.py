from pyrogram import Client, filters
import requests
from PyroUbot import *

__MODULE__ = "capcutdl"
__HELP__ = f"""📖 <u><b>Folder Module Capcutdl</b></u>>

<blockquote><b>📚 perintah: .cpcutdl [LINK]</b>
<b>📝 penjelasan: untuk mendownload template/video capcut</b></blockquote>"""




@PY.UBOT("capcutdl")
async def capcut_download(client, message):
    if len(message.command) < 2:
        await message.reply_text("<b>📚 Gunakan Format:</b>\n<b>🌸 .capcutdl [url]</b>")
        return
    
    url = message.command[1]
    processing_msg = await message.reply_text("<b>💬 was running wait a minute. ✨</b>")
    
    response = requests.get(f"https://api.botcahx.eu.org/api/download/capcut?url={url}&apikey=VENOZY")
    data = response.json()
    
    if not data.get("status"):
        await processing_msg.edit_text("❌ Gagal mengambil data. Pastikan URL valid.")
        return
    
    video_url = data["result"]["video"]
    thumbnail_url = data["result"]["thumbnail"]
    title = data["result"].get("short_title", "CapCut Video")
    author = data["result"].get("author", {}).get("name", "Unknown")
    
    await message.reply_video(
        video=video_url,
        thumb=thumbnail_url,
        caption=f"**{title}**\n👤 Pembuat: {author}\n🔗 [Sumber]({url})",
    )
    
    await processing_msg.delete()