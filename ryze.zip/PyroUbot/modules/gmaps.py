from geopy.geocoders import Nominatim
from PyroUbot  import *

__MODULE__ = "gmaps"
__HELP__ = """
📖 <u><b>Folder Module Gmaps</b></u>

<b>★ ᴘᴇʀɪɴᴛᴀʜ: .maps [nama]</b>
<b>╰ ᴘᴇɴᴊᴇʟᴀsᴀɴ: untuk mencari lokasi yang kamu cari</b>"""

@PY.UBOT("gps|maps")
async def gps(client, message):
    input_str = message.text.split(" ", 1)
    
    if len(input_str) < 2:
        return await message.reply("<b>👉 Mohon Gunakan Nama Tempat Yang Ingin Kamu Cari.</b>")
    
    input_str = input_str[1]
    await message.reply("<b>💬 was running wait a minute. ✨</b>")
   
    geolocator = Nominatim(user_agent="bot")
    geoloc = geolocator.geocode(input_str)
    
    if geoloc:
        lon = geoloc.longitude
        lat = geoloc.latitude
        await message.reply_location(latitude=lat, longitude=lon)
    else:
        await message.reply("sᴀʏᴀ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴᴇᴍᴜᴋᴀɴɴʏᴀ.")