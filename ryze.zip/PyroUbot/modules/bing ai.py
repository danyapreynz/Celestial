__MODULE__ = "bing ai"
__HELP__ =  """📖 <u><b>Folder Module Bing Ai</b></u>

<blockquote><b>📚 perintah: .bing</b>
<b>📝 penjelasan: untuk membuat pertanyaan bing ai</b></blockquote>"""
