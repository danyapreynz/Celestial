import requests
from pyrogram import Client, filters
from PyroUbot import *

__MODULE__ = "leptonai"
__HELP__ =  """
📖 <u><b>Folder Module Lepton Ai</b></u>

<blockquote><b>📚 perintah: .leptonai [ᴛᴇxᴛ]</b>
<b>📝 penjelasan: untuk mengetahui informasi dari lepton ai</b></blockquote>"""

@PY.UBOT("leptonai")
async def _(client, message):
    if len(message.command) < 2:
        await message.reply_text("<b> ɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ: .leptonai [ᴛᴇxᴛ]</b>\n<b>ᴜɴᴛᴜᴋ ᴍᴇɴᴄᴀʀɪ ᴍᴀᴋɴᴀ ᴛᴇʀsᴇᴍʙᴜɴʏɪ ᴅɪ ʙᴀʟɪᴋ ɴᴀᴍᴀᴍᴜ</b>")
        return
    
    tt = " ".join(message.command[1:])
    url = f"https://api.botcahx.eu.org/api/search/lepton-ai?text={tt}&apikey=VENOZY"
    
    await message.reply_text("<b>💬 was running wait a minute. ✨</b>")
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if data["status"]:
            await message.reply_text(f"""<blockquote><b>{data['result']['result']}</b></blockquote>""")
        else:
            await message.reply_text("eror")
    else:
        await message.reply_text("eror")
