import requests
from PyroUbot import *

__MODULE__ = "kecocokan"
__HELP__ = f"""📖 <u><b>Folder Module Kecocokan</b></u>>

<blockquote><b>📚 perintah: .kecocokannama [ɴᴀᴍᴀ][ᴛᴀɴɢɢᴀʟ][ʙᴜʟᴀɴ][ᴛᴀʜᴜɴ]</b>
<b>📝 penjelasan: untuk mengecek kecocokan dari namamu</b></blockquote>
<blockquote><b>📚 perintah: .kecocokanpasangan [ɴᴀᴍᴀ ᴄᴏᴡᴏ][ɴᴀᴍᴀ ᴄᴇᴡᴇ]</b>
<b>📝 penjelasan: untuk mengecek kecocokan dari pasanganmu</b></blockquote>"""
@PY.UBOT("kecocokanpasangan|cekpasangan")
async def get_shio(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply_text("<b>📚 Gunakan Format:</b>\n<b>🌸 .kecocokanpasangan [ɴᴀᴍᴀ ᴄᴏᴡᴏ][ɴᴀᴍᴀ ᴄᴇᴡᴇ]</b>")

    cowo, cewe = args[1], args[2]
    API_URL = f"https://api.botcahx.eu.org/api/primbon/kecocokanpasangan?cowo={cowo}&cewe={cewe}&apikey=VENOZY"
    try:
        response = requests.get(API_URL)
        data = response.json()

        if not data.get("status") or not data["result"].get("status"):
            return await message.reply_text("⚠️ Data tidak ditemukan atau terjadi kesalahan.")

        result = data["result"]["message"]
        nama = result["nama_anda"]
        arti = result["nama_pasangan"]
        positif = result["sisi_positif"]
        negatif = result["sisi_negatif"]

        reply_text = (
            f"✨ <b>kecocokan pasangan</b>"
            f"<blockquote>👨 <b>nama cowo: {nama}</b>\n"
            f"👱‍♀️<b>nama cewe: {arti}</b>\n"
            f"<b>╴╴╴╴╴╴╴╴╴╴╴╴╴╴╴╴╴╴╴</b>\n"
            f"👉 <b>sisi positif:</b> {positif}\n\n"
            f"👀 <b>sisi negatif:</b> {negatif}</blockquote>"
        )

        await message.reply_text(reply_text, disable_web_page_preview=True)

    except Exception as e:
        await message.reply_text(f"⚠️ Terjadi kesalahan: `{e}`")

@PY.UBOT("kecocokannama|ceknama")
async def get_shio(client, message):
    args = message.text.split()
    if len(args) < 5:
        return await message.reply_text("<b>📚 Gunakan Format:</b>\n<b>🌸 .kecocokannama [ɴᴀᴍᴀ][ᴛᴀɴɢɢᴀʟ][ʙᴜʟᴀɴ][ᴛᴀʜᴜɴ]</b>")

    shio, tanggal, bulan, tahun = args[1], args[2], args[3], args[4]
    API_URL = f"https://api.botcahx.eu.org/api/primbon/kecocokannama?nama={shio}&tanggal={tanggal}&bulan={bulan}&tahun={tahun}&apikey=VENOZY"
    try:
        response = requests.get(API_URL)
        data = response.json()

        if not data.get("status") or not data["result"].get("status"):
            return await message.reply_text("⚠️ Data tidak ditemukan atau terjadi kesalahan.")

        result = data["result"]["message"]
        nama = result["nama"]
        arti = result["persentase_kecocokan"]

        reply_text = (
            f"<blockquote>✨ <b>kecocokan nama: {nama}</b>\n"
            f"🗓 <b>tanggal lahir: {tanggal}-{bulan}-{tahun}</b>\n"
            f"<b>=======================</b>\n"
            f"👉 <b>kecocokan:</b> {arti}</blockquote>"
        )

        await message.reply_text(reply_text, disable_web_page_preview=True)

    except Exception as e:
        await message.reply_text(f"⚠️ Terjadi kesalahan: `{e}`")

