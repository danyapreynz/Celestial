import random
from pyrogram.enums import MessagesFilter
from PyroUbot import *

__MODULE__ = "asupan"
__HELP__ =  """📖 <u><b>Folder Module Asupan</b></u>

<blockquote><b>📚 perintah: .asupan</b>
<b>📝 penjelasan: untuk mencari video asupan random</b></blockquote>
<blockquote><b>📚 perintah: .cewek</b>
<b>📝 penjelasan: untuk mencari foto cewe random</b></blockquote>"""


@PY.UBOT("asupan")
@PY.TOP_CMD
async def video_asupan(client, message):
    prs = await EMO.PROSES(client)
    y = await message.reply_text(f"<b>💬 was running wait a minute. ✨</b>")
    try:
        asupannya = []
        async for asupan in client.search_messages(
            "@AsupanNyaSaiki", filter=MessagesFilter.VIDEO
        ):
            asupannya.append(asupan)
        video = random.choice(asupannya)
        await video.copy(message.chat.id, reply_to_message_id=message.id)
        await y.delete()
    except Exception as error:
        await y.edit(error)


@PY.UBOT("cewek")
@PY.TOP_CMD
async def photo_cewek(client, message):
    prs = await EMO.PROSES(client)
    y = await message.reply_text(f"<b>💬 was running wait a minute. ✨</b>")
    try:
        ayangnya = []
        async for ayang in client.search_messages(
            "@AyangSaiki", filter=MessagesFilter.PHOTO
        ):
            ayangnya.append(ayang)
        photo = random.choice(ayangnya)
        await photo.copy(message.chat.id, reply_to_message_id=message.id)
        await y.delete()
    except Exception as error:
        await y.edit(error)
