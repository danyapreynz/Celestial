import asyncio
import random

import requests
from pyrogram import *
from pyrogram.errors.exceptions.flood_420 import FloodWait
from pyrogram.types import *

from PyroUbot import *

DEFAULTUSER = "Nay"

__MODULE__ = "animasi2"
__HELP__ =  """📖 <u><b>Folder Module Animasi2 </b></u>

<blockquote><b>📚 perintah: .zombi or .alien</b>
<b>📝 penjelasan: untuk memunculkan animasi zombi / alien</b></blockquote>
<blockquote><b>📚 perintah: .muak or .nihlop</b>
<b>📝 penjelasan: untuk memunculkan animasi muak / nihlop</b></blockquote>
<blockquote><b>📚 perintah: .cilukba or .uler</b>
<b>📝 penjelasan: untuk memunculkan animasi cilukba / uler</b></blockquote>
<blockquote><b>📚 perintah: .kurakura or .haha</b>
<b>📝 penjelasan: untuk memunculkan animasi kurakura / haha</b></blockquote>
<blockquote><b>📚 perintah: .tengkorak or .orang</b>
<b>📝 penjelasan: untuk memunculkan animasi tengkorak / orang</b></blockquote>
<blockquote><b>📚 perintah: .rumah or .tidur</b>
<b>📝 penjelasan: untuk memunculkan animasi rumah / tidur</b></blockquote>
<blockquote><b>📚 perintah: .ap or .apa</b>
<b>📝 penjelasan: untuk memunculkan animasi ap / apa</b></blockquote>
<blockquote><b>📚 perintah: .pikacu or .untukmu</b>
<b>📝 penjelasan: untuk memunculkan animasi pikacu / untukmu</b></blockquote>
<blockquote><b>📚 perintah: .mokat or .xd</b>
<b>📝 penjelasan: untuk memunculkan animasi mokat / xd</b></blockquote>
<blockquote><b>📚 perintah: .skul or jir .kecoa</b>
<b>📝 penjelasan: untuk memunculkan animasi skul / kecoa</b></blockquote>
<blockquote><b>📚 perintah: .mbe or .p
<b>📝 penjelasan: untuk memunculkan animasi mbe / p</b></blockquote>"""

NOBLE = [
    "╲╲╲┏┓╭╮╱╱╱\n╲╲╲┗┓┏┛┃╭╮┃╱╱╱\n╲╲╲╲┃┃┏┫┃╭┻┻┓╱╱\n╱╱╱┏╯╰╯┃╰┫┏╯╱╱\n╱╱┏┻┳┳┻┫┗┓╱╱╱\n╱╱╰┓┃┃╲┏┫┏┛╲╲╲\n╱╱╱╱┃╰╯╲┃┃┗╮╲╲\n╱╱╱╱╰╯╰┛╲╲",
    "┏╮\n┃▔┃▂▂┏┓┏┳┓\n┃▂┣┻╮┃┃▂┃▂┏╯\n┃▔┃▔╭╮▔┃┃┃▔┃▔┗┓\n┃▂┃▂╰╯▂┃┗╯▂┃▂▂▂┃\n┃▔┗╮┃▔▔▔┃▔┏╯\n┃▂▂▂▂▂┣╯▂▂▂┃▂┗╮\n┗┻┻┛",
    "┏┓┏┳┳┳┓\n┃┗┫╋┣┓┃┏┫┻┫\n┗┻┛┗┛┗┛\n­­­­­­­­­YOU",
    "╦╔╗╗╔╔ \n║║║║║╠ \n╚═╚╝╚╝╚ \n╦╦╔╗╦╦   \n╚╦╝║║║║ \n╩╚╝╚╝",
    "╔══╗....<3 \n╚╗╔╝..('\\../') \n╔╝╚╗..( . ) \n╚══╝..(,,)(,,) \n╔╗╔═╦╦╦═╗ ╔╗╔╗ \n║╚╣║║║║╩╣ ║╚╝║ \n╚═╩═╩═╩═╝ ╚══╝",
    "░I░L░O░V░E░Y░O░U░",
    "┈┈╭╱▔▔▔▔╲╮┈┈┈\n┈┈╰╱╭▅╮╭▅╮╲╯┈┈┈\n╳┈┈▏╰┈▅▅┈╯▕┈┈┈┈\n┈┈┈╲┈╰╯┈╱┈┈╳┈\n┈┈┈╱╱▔╲╱▔╲╲┈┈┈┈\n┈╭╮▔▏┊┊▕▔╭╮┈╳\n┈┃┊┣▔╲┊┊╱▔┫┊┃┈┈\n┈╰╲╱╯┈╳",
    "╔ღ═╗╔╗\n╚╗╔╝║║ღ═╦╦╦═ღ\n╔╝╚╗ღ╚╣║║║║╠╣\n╚═ღ╝╚═╩═╩ღ╩═╝",
    "╔══╗ \n╚╗╔╝ \n╔╝(¯'v'¯) \n╚══'.¸./\n╔╗╔═╦╦╦═╗ ╔╗╔╗ \n║╚╣║║║║╩╣ ║╚╝║ \n╚═╩═╩═╩═╝ ╚══╝",
    "╔╗ \n║║╔═╦═╦═╦═╗ ╔╦╗ \n║╚╣╬╠╗║╔╣╩╣ ║║║ \n╚═╩═╝╚═╝╚═╝ ╚═╝ \n╔═╗ \n║═╬═╦╦╦═╦═╦═╦═╦═╗ \n║╔╣╬║╔╣╩╬╗║╔╣╩╣╔╝ \n╚╝╚═╩╝╚═╝╚═╝╚═╩╝",
    "╔══╗ \n╚╗╔╝ \n╔╝╚╗ \n╚══╝ \n╔╗ \n║║╔═╦╦╦═╗ \n║╚╣║║║║╚╣ \n╚═╩═╩═╩═╝ \n╔╗╔╗ ♥️ \n║╚╝╠═╦╦╗ \n╚╗╔╣║║║║ \n═╚╝╚═╩═╝",
    "╔══╗╔╗  ♡ \n╚╗╔╝║║╔═╦╦╦╔╗ \n╔╝╚╗║╚╣║║║║╔╣ \n╚══╝╚═╩═╩═╩═╝\n­­­­­­­­­­­­YOU",
    "╭╮╭╮╮╭╮╮╭╮╮╭╮╮ \n┃┃╰╮╯╰╮╯╰╮╯╰╮╯ \n┃┃╭┳┳╮╭┳╮ \n┃┃┃┃╭╮┣╮┃┃╭┫╭╮┃ \n┃╰╯┃╰╯┃┃╰╯┃┃╰┻┻╮ \n╰┻╯╰╯╰╯",
    "┊┊╭╮┊┊┊┊┊┊┊┊┊┊┊ \n╋╯┊┊┊┊┊┊┊┊┊┊┊ \n┊┊┃┊╭┳╮╭┓┊╭╮╭╮ \n╭╋╋╯┣╯┃┊┃╰╋╯ \n╰╯┊╰╯┊╰┛┊╰",
]

@PY.UBOT("loveyou")
@PY.TOP_CMD
async def lopeyo(client, message):
    noble = random.randint(1, len(NOBLE) - 2)
    reply_text = NOBLE[noble]
    await message.reply(reply_text)


@PY.UBOT("hmm")
@PY.TOP_CMD
async def hmmm(client, message):
    mg = await message.reply(
        "┈┈╱▔▔▔▔▔╲┈┈┈HM┈HM\n┈╱┈┈╱▔╲╲╲▏┈┈┈HMMM\n╱┈┈╱╱▔▔▔▔▔╲╮┈┈\n▏┈▕┃▕╱▔╲╱▔╲▕╮┃┈┈\n▏┈▕╰▏▊▕▕▋▕▕╯┈┈\n╲┈┈╲╱▔╭╮▔▔┳╲╲┈┈┈\n┈╲┈┈▏╭╯▕▕┈┈┈\n┈┈╲┈╲▂▂▂▂▂▂╱╱┈┈┈\n┈┈┈┈▏┊┈┈┈┈┊┈┈┈╲\n┈┈┈┈▏┊┈┈┈┈┊▕╲┈┈╲\n┈╱▔╲▏┊┈┈┈┈┊▕╱▔╲▕\n┈▏┈┈┈╰┈┈┈┈╯┈┈┈▕▕\n┈╲┈┈┈╲┈┈┈┈╱┈┈┈╱┈╲\n┈┈╲┈┈▕▔▔▔▔▏┈┈╱╲╲╲▏\n┈╱▔┈┈▕┈┈┈┈▏┈┈▔╲▔▔\n┈╲▂▂▂╱┈┈┈┈╲▂▂▂╱┈ ",
    )


@PY.UBOT("ktl")
@PY.TOP_CMD
async def kntl(client, message):
    emoji = get_text(message)
    kontol = MEMES.GAMBAR_KONTOL
    if emoji:
        kontol = kontol.replace("⡀", emoji)
    await message.reply(kontol)


@PY.UBOT("penis")
@PY.TOP_CMD
async def pns(client, message):
    emoji = get_text(message)
    titid = MEMES.GAMBAR_TITIT
    if emoji:
        titid = titid.replace("😋", emoji)
    await message.reply(titid)


@PY.UBOT("heli")
@PY.TOP_CMD
async def helikopter(client, message):
    await message.reply(
        "▬▬▬.◙.▬▬▬ \n"
        "═▂▄▄▓▄▄▂ \n"
        "◢◤ █▀▀████▄▄▄▄◢◤ \n"
        "█▄ █ █▄ ███▀▀▀▀▀▀▀╬ \n"
        "◥█████◤ \n"
        "══╩══╩══ \n"
        "╬═╬ \n"
        "╬═╬ \n"
        "╬═╬ \n"
        "╬═╬ \n"
        "╬═╬ \n"
        "╬═╬ \n"
        "╬═╬ Hallo Semuanya :) \n"
        "╬═╬☻/ \n"
        "╬═╬/▌ \n"
        "╬═╬/ \\ \n",
    )


@PY.UBOT("tembak")
@PY.TOP_CMD
async def dornembak(client, message):
    await message.reply(
        "_/﹋\\_\n" "(҂`_´)\n" "<,︻╦╤ ҉\n" r"_/﹋\_" "\nMau Jadi Pacarku Gak?!",
    )


@PY.UBOT("bundir")
@PY.TOP_CMD
async def ngebundir(client, message):
    await message.reply(
        "`Dadah Semuanya...`          \n　　　　　|"
        "\n　　　　　| \n"
        "　　　　　| \n"
        "　　　　　| \n"
        "　　　　　| \n"
        "　　　　　| \n"
        "　　　　　| \n"
        "　　　　　| \n"
        "　／￣￣＼| \n"
        "＜ ´･ 　　 |＼ \n"
        "　|　３　 | 丶＼ \n"
        "＜ 、･　　|　　＼ \n"
        "　＼＿＿／∪ _ ∪) \n"
        "　　　　　 Ｕ Ｕ\n",
    )


@PY.UBOT("awk")
@PY.TOP_CMD
async def awikwok(client, message):
    await message.reply(
        "██▀▀▀██\n"
        "▄▀█▄▄▄▄▀█▄▄▄\n"
        "▄▀█▄▄██▄▄\n"
        "▄▄▄▀▀▄▄▄▄▀▀▄\n"
        "▀▀▀▀▀▀\n`Awkwokwokwok..`",
    )


@PY.UBOT("ok")
@PY.TOP_CMD
async def ysaja(client, message):
    await message.reply(
        "‡‡‡‡‡‡‡‡‡‡‡‡▄▄▄▄\n"
        "‡‡‡‡‡‡‡‡‡‡‡█‡‡‡‡█\n"
        "‡‡‡‡‡‡‡‡‡‡‡█‡‡‡‡█\n"
        "‡‡‡‡‡‡‡‡‡‡█‡‡‡‡‡█\n"
        "‡‡‡‡‡‡‡‡‡█‡‡‡‡‡‡█\n"
        "██████▄▄█‡‡‡‡‡‡████████▄\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█████‡‡‡‡‡‡‡‡‡‡‡‡██\n"
        "█████‡‡‡‡‡‡‡██████████\n",
    )
@PY.UBOT("bot")
@PY.TOP_CMD
async def bot(client, message):
    await message.reply("🤖") 


@PY.UBOT("tank")
async def tank(client, message):
    await message.reply(
        "█۞███████]▄▄▄▄▄▄▄▄▄▄▃ \n"
        "▂▄▅█████████▅▄▃▂…\n"
        "[███████████████████]\n"
        "◥⊙▲⊙▲⊙▲⊙▲⊙▲⊙▲⊙◤\n",
    )


@PY.UBOT("babi")
@PY.TOP_CMD
async def babi(client, message):
    await message.reply(
        "┈┈┏╮╭┓┈╭╮\n"
        "┈┈┃┏┗┛┓┃╭┫Ngok ┃\n"
        "┈┈╰┓▋▋┏╯╯╰╯\n"
        "┈╭┻╮╲┗╮╭╮┈\n"
        "┈┃▎▎┃╲╲╲╲╲╲┣╯┈\n"
        "┈╰┳┻▅╯╲╲╲╲┃┈┈┈\n"
        "┈┈┈╰┳┓┏┳┓┏╯┈┈┈\n"
        "┈┈┈┈┈┗┻┛┗┻┛┈┈┈┈\n",
    )


@PY.UBOT("ange")
@PY.TOP_CMD
async def piciieess(client, message):
    e = await message.edit("Ayanggg 😖")
    await asyncio.sleep(2)
    await e.edit("Aku Ange 😫")
    await asyncio.sleep(2)
    await e.edit("Ayuukk Picies Yang 🤤")


@PY.UBOT("lipkol")
@PY.TOP_CMD
async def lipkoll(client, message):
    e = await message.edit("Ayanggg 😖")
    await asyncio.sleep(2)
    await e.edit("Kangeeen 👉👈")
    await asyncio.sleep(2)
    await e.edit("Pingiinn Slipkool Yaaang 🥺👉👈")


@PY.UBOT("nakal")
@PY.TOP_CMD
async def nakall(client, message):
    e = await message.edit("Ayanggg ih🥺")
    await asyncio.sleep(2)
    await e.edit("Nakal Banget Dah Ayang 🥺")
    await asyncio.sleep(2)
    await e.edit("Aku Gak Like Ayang 😠")
    await asyncio.sleep(2)
    await e.edit("Pokoknya Aku Gak Like Ih 😠")


@PY.UBOT("piss")
@PY.TOP_CMD
async def peace(client: Client, message: Message):
    await message.reply(
        "┈┈┈┈PEACE MAN┈┈┈┈\n"
        "┈┈┈┈┈┈╭╮╭╮┈┈┈┈┈┈\n"
        "┈┈┈┈┈┈┃┃┃┃┈┈┈┈┈┈\n"
        "┈┈┈┈┈┈┃┃┃┃┈┈┈┈┈┈\n"
        "┈┈┈┈┈┈┃┗┛┣┳╮┈┈┈┈\n"
        "┈┈┈┈┈╭┻┓┃┃┈┈┈┈\n"
        "┈┈┈┈┈┃╲┏╯┻┫┈┈┈┈\n"
        "┈┈┈┈┈╰╮╯┊┊╭╯┈┈┈┈\n",
    )


@PY.UBOT("spongebob")
@PY.TOP_CMD
async def spongebobss(client: Client, message: Message):
    await message.reply(
        "╲┏┳┓╲╲\n"
        "╲┃◯┃╭┻┻╮╭┻┻╮┃╲╲\n"
        "╲┃╮┃┃╭╮┃┃╭╮┃┃╲╲\n"
        "╲┃╯┃┗┻┻┛┗┻┻┻┻╮╲\n"
        "╲┃◯┃╭╮╰╯┏┳╯╲\n"
        "╲┃╭┃╰┏┳┳┳┳┓◯┃╲╲\n"
        "╲┃╰┃◯╰┗┛┗┛╯╭┃╲╲\n",
    )



@PY.UBOT("kocok")
@PY.TOP_CMD
async def kocokk(client, message):
    e = await message.edit("KOCOKINNNN DONG SAYANKKKKK🤤🤤🥵🥵")
    await asyncio.sleep(0.2)
    await e.edit("8✊====D")
    await asyncio.sleep(0.2)
    await e.edit("8=✊===D")
    await asyncio.sleep(0.2)
    await e.edit("8==✊==D")
    await asyncio.sleep(0.2)
    await e.edit("8===✊=D")
    await asyncio.sleep(0.2)
    await e.edit("8====✊D")
    await asyncio.sleep(0.2)
    await e.edit("8===✊=D")
    await asyncio.sleep(0.2)
    await e.edit("8==✊==D")
    await asyncio.sleep(0.2)
    await e.edit("8=✊===D")
    await asyncio.sleep(0.2)
    await e.edit("8✊====D")
    await asyncio.sleep(0.2)
    await e.edit("8=✊===D")
    await asyncio.sleep(0.2)
    await e.edit("8==✊==D")
    await asyncio.sleep(0.2)
    await e.edit("8===✊=D")
    await asyncio.sleep(0.2)
    await e.edit("8====✊D")
    await asyncio.sleep(0.2)
    await e.edit("8===✊=D")
    await asyncio.sleep(0.2)
    await e.edit("8==✊==D")
    await asyncio.sleep(0.2)
    await e.edit("8=✊===D")
    await asyncio.sleep(0.2)
    await e.edit("8✊====D")
    await asyncio.sleep(0.2)
    await e.edit("8=✊===D")
    await asyncio.sleep(0.2)
    await e.edit("8==✊==D")
    await asyncio.sleep(0.2)
    await e.edit("8===✊=D")
    await asyncio.sleep(0.2)
    await e.edit("8====✊D💦")
    await asyncio.sleep(0.2)
    await e.edit("8===✊=D💦💦")
    await asyncio.sleep(0.2)
    await e.edit("8==✊==D💦💦💦")
    await asyncio.sleep(0.2)
    await e.edit("8=✊===D💦💦💦💦")
    await asyncio.sleep(0.2)
    await e.edit("8✊====D💦💦💦💦💦")
    await asyncio.sleep(0.2)
    await e.edit("8=✊====D💦💦💦💦💦💦")
    await asyncio.sleep(0.2)
    await e.edit("8==✊==D💦💦💦💦💦💦💦")
    await asyncio.sleep(0.2)
    await e.edit("8===✊=D💦💦💦💦💦💦💦💦")
    await asyncio.sleep(0.2)
    await e.edit("8====✊D💦💦💦💦💦💦💦💦")
    await asyncio.sleep(0.2)
    await e.edit("**CROOTTTT**")
    await asyncio.sleep(0.2)
    await e.edit("**CROOTTTT AAAHHH BASAHH.....**")
    await asyncio.sleep(0.2)
    await e.edit("**AHHH ENAKKKKK SAYANGGGG🤤🤤🥵🥵**")


        
  
@PY.UBOT("dino")
@PY.TOP_CMD
async def adadino(client: Client, message: Message):
    typew = await message.edit("`DIN DINNN.....`")
    await asyncio.sleep(1)
    await typew.edit("`DINOOOOSAURUSSSSS!!`")
    await asyncio.sleep(1)
    await typew.edit("`🏃                        🦖`")
    await typew.edit("`🏃                       🦖`")
    await typew.edit("`🏃                      🦖`")
    await typew.edit("`🏃                     🦖`")
    await typew.edit("`🏃   `LARII`          🦖`")
    await typew.edit("`🏃                   🦖`")
    await typew.edit("`🏃                  🦖`")
    await typew.edit("`🏃                 🦖`")
    await typew.edit("`🏃                🦖`")
    await typew.edit("`🏃               🦖`")
    await typew.edit("`🏃              🦖`")
    await typew.edit("`🏃             🦖`")
    await typew.edit("`🏃            🦖`")
    await typew.edit("`🏃           🦖`")
    await typew.edit("`🏃WOARGH!   🦖`")
    await typew.edit("`🏃           🦖`")
    await typew.edit("`🏃            🦖`")
    await typew.edit("`🏃             🦖`")
    await typew.edit("`🏃              🦖`")
    await typew.edit("`🏃               🦖`")
    await typew.edit("`🏃                🦖`")
    await typew.edit("`🏃                 🦖`")
    await typew.edit("`🏃                  🦖`")
    await typew.edit("`🏃                   🦖`")
    await typew.edit("`🏃                    🦖`")
    await typew.edit("`🏃                     🦖`")
    await typew.edit("`🏃  Huh-Huh           🦖`")
    await typew.edit("`🏃                   🦖`")
    await typew.edit("`🏃                  🦖`")
    await typew.edit("`🏃                 🦖`")
    await typew.edit("`🏃                🦖`")
    await typew.edit("`🏃               🦖`")
    await typew.edit("`🏃              🦖`")
    await typew.edit("`🏃             🦖`")
    await typew.edit("`🏃            🦖`")
    await typew.edit("`🏃           🦖`")
    await typew.edit("`🏃          🦖`")
    await typew.edit("`🏃         🦖`")
    await typew.edit("`DIA SEMAKIN MENDEKAT!!!`")
    await asyncio.sleep(1)
    await typew.edit("`🏃       🦖`")
    await typew.edit("`🏃      🦖`")
    await typew.edit("`🏃     🦖`")
    await typew.edit("`🏃    🦖`")
    await typew.edit("`Dahlah Pasrah Aja`")
    await asyncio.sleep(1)
    await typew.edit("`🧎🦖`")
    await asyncio.sleep(2)
    await typew.edit("`-TAMAT-`")


@PY.UBOT("ajg")
@PY.TOP_CMD
async def anjg(client, message):
    await message.reply(
        "╥╭╮┳\n"
        "╢╭╮╭┫┃▋▋▅┣\n"
        "╢┃╰┫┈┈┈┈┈┃┃┈┈╰┫┣\n"
        "╢╰┫┈┈┈┈┈╰╯╰┳╯┣\n"
        "╢┊┊┃┏┳┳┓┏┳┫┊┊┣\n"
        "╨┗┛┗┛┗┛┗┛┻\n",
    )
@PY.UBOT("kecoa")
@PY.TOP_CMD
async def anjg(client, message):
    await message.reply("    ╚⊙ ⊙╝..\n"
                     "   ╚═(███)═╝\n"
                     "    ╚═(███)═╝\n"
                     "       ╚═(███)═╝\n"
                     "        ╚═(███)═╝\n"
                     "        ╚═(███)═╝\n"
                     "        ╚═(███)═╝\n"
                     "      ╚═(███)═╝\n"
                     "     ╚═(███)═╝\n"
                     "    ╚═(███)═╝ \n"
                     "    ╚═(███)═╝\n"
                     "     ╚═(███)═╝\n"
                     "      ╚═(███)═╝\n"
                     "       ╚═(███)═╝\n"
                     "        ╚═(███)═╝\n"
                     "        ╚═(███)═╝\n"
                     "       ╚═(███)═╝\n"
                     "      ╚═(███)═╝\n"
                     "     ╚═(███)═╝\n"
                     "     ╚═(███)═╝\n"
                     "      ╚═(█)═╝\n"
                     " BAPAK LU KECOA \n")    
@PY.UBOT("fuck")
@PY.TOP_CMD
async def anjg(client, message):
    await message.reply("░░░░░░░░░░░░░░░▄▄░░░░░░░░░░░\n"
                     "░░░░░░░░░░░░░░█░░█░░░░░░░░░░\n"
                     "░░░░░░░░░░░░░░█░░█░░░░░░░░░░\n"
                     "░░░░░░░░░░░░░░█░░█░░░░░░░░░░\n"
                     "░░░░░░░░░░░░░░█░░█░░░░░░░░░░\n"
                     "██████▄███▄████░░███▄░░░░░░░\n"
                     "▓▓▓▓▓▓█░░░█░░░█░░█░░░███░░░░\n"
                     "▓▓▓▓▓▓█░░░█░░░█░░█░░░█░░█░░░\n"
                     "▓▓▓▓▓▓█░░░░░░░░░░░░░░█░░█░░░\n"
                     "▓▓▓▓▓▓█░░░░░░░░░░░░░░░░█░░░░\n"
                     "▓▓▓▓▓▓█░░░░░░░░░░░░░░██░░░░░\n"
                     "▓▓▓▓▓▓█████░░░░░░░░░██░░░░░░\n")                    
@PY.UBOT("canda")
@PY.TOP_CMD
async def anjg(client, message):
    await message.reply(
            "`⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀\n ⠀⣴⠿⠏⠀⠀⠀⠀⠀   ⢳⡀⠀⡏⠀⠀⠀   ⠀⢷\n⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀  ⠀   ⡇\n⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿  ⣸ Kamu    ⡇\n ⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀  ⣿  ⢹⠀        ⡇\n  ⠙⢿⣯⠄⠀⠀⠀__⠀⠀⡿ ⠀⡇⠀⠀⠀⠀    ⡼\n⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀   ⠘⠤⣄⣠⠞⠀\n⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀\n⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀\n⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀ ⠀⣄⢸⠀⠀⠀⠀⠀⠀`",
            "`⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀\n ⠀⣴⠿⠏⠀⠀⠀⠀⠀  ⠀⢳⡀⠀⡏⠀⠀⠀   ⠀⢷\n⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀      ⡇\n⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿  ⣸ Pasti   ⡇\n ⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀  ⣿  ⢹⠀        ⡇\n  ⠙⢿⣯⠄⠀⠀|__|⠀⠀⡿ ⠀⡇⠀⠀⠀⠀    ⡼\n⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀   ⠘⠤⣄⣠⠞⠀\n⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀\n⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀\n⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀ ⠀⣄⢸⠀⠀⠀⠀⠀⠀`",
            "`⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀\n ⠀⣴⠿⠏⠀⠀     ⠀⢳⡀⠀⡏⠀⠀    ⠀⢷\n⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀⠀     ⡇\n⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿  ⣸ Belum   ⡇\n ⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀  ⣿  ⢹⠀         ⡇\n  ⠙⢿⣯⠄⠀⠀(x)⠀⠀⡿ ⠀⡇⠀⠀⠀⠀    ⡼\n⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀   ⠘⠤⣄⣠⠞⠀\n⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀\n⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀\n⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀ ⠀⣄⢸⠀⠀⠀⠀⠀⠀`",
            "`⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀\n ⠀⣴⠿⠏⠀⠀     ⠀⢳⡀⠀⡏⠀⠀    ⠀⢷\n⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀   ⠀     ⡇\n⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿  ⣸ Mandi  ⡇\n ⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀   ⣿  ⢹⠀        ⡇\n  ⠙⢿⣯⠄⠀⠀⠀__ ⠀⠀⡿ ⠀⡇⠀⠀⠀⠀    ⡼\n⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀   ⠘⠤⣄⣠⠞⠀\n⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀\n⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀\n⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀ ⠀⣄⢸⠀⠀⠀⠀⠀⠀`",
            "`⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀\n ⠀⣴⠿⠏⠀⠀⠀⠀⠀   ⢳⡀⠀⡏⠀⠀    ⠀⢷\n⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀ ⠀     ⡇\n⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿  ⣸ Bwhaha  ⡇\n ⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀  ⣿  ⢹⠀        ⡇\n  ⠙⢿⣯⠄⠀⠀|__| ⠀⡿ ⠀⡇⠀⠀⠀⠀    ⡼\n⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀   ⠘⠤⣄⣠⠞⠀\n⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀\n⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀\n⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀ ⠀⣄⢸⠀⠀⠀⠀⠀⠀`",
            "`⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀\n ⠀⣴⠿⠏⠀⠀⠀⠀⠀  ⠀⢳⡀⠀⡏⠀⠀    ⠀⢷\n⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀  ⠀     ⡇\n⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿  ⣸ Canda   ⡇\n ⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀   ⣿  ⢹⠀        ⡇\n  ⠙⢿⣯⠄⠀⠀****⠀⠀⡿ ⠀⡇⠀⠀⠀⠀    ⡼\n⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀   ⠘⠤⣄⣠⠞⠀\n⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀\n⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀\n⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀ ⠀⣄⢸⠀⠀⠀⠀⠀⠀`")
@PY.UBOT("skul|jir")
@PY.TOP_CMD
async def anjg(client, message):
    await message.reply("███████████████████████████\n"
                     "███████▀▀▀░░░░░░░▀▀▀███████\n"
                     "████▀░░░░░░░░░░░░░░░░░▀████\n"
                     "███│░░░░░░░░░░░░░░░░░░░│███\n"
                     "██▌│░░░░░░░░░░░░░░░░░░░│▐██\n"
                     "██░└┐░░░░░░░░░░░░░░░░░┌┘░██\n"
                     "██░░└┐░░░░░░░░░░░░░░░┌┘░░██\n"
                     "██░░┌┘▄▄▄▄▄░░░░░▄▄▄▄▄└┐░░██\n"
                     "██▌░│██████▌░░░▐██████│░▐██\n"
                     "███░│▐███▀▀░░▄░░▀▀███▌│░███\n"
                     "██▀─┘░░░░░░░▐█▌░░░░░░░└─▀██\n"
                     "██▄░░░▄▄▄▓░░▀█▀░░▓▄▄▄░░░▄██\n"
                     "████▄─┘██▌░░░░░░░▐██└─▄████\n"
                     "█████░░▐█─┬┬┬┬┬┬┬─█▌░░█████\n"
                     "████▌░░░▀┬┼┼┼┼┼┼┼┬▀░░░▐████\n"
                     "█████▄░░░└┴┴┴┴┴┴┴┘░░░▄█████\n"
                     "███████▄░░░░░░░░░░░▄███████\n"
                     "██████████▄▄▄▄▄▄▄██████████\n"
                     "███████████████████████████\n")
                     
@PY.UBOT("nah")
@PY.TOP_CMD
async def nahlove(client, message):
    typew = await message.reply("`\n(\\_/)`" "`\n(●_●)`" "`\n />💖 *Ini Buat Kamu`")
    await asyncio.sleep(2)
    await typew.edit("`\n(\\_/)`" "`\n(●_●)`" "`\n💖<\\  *Tapi Bo'ong`")

@PY.UBOT("lawas")
@PY.TOP_CMD
async def nakall(client, message):
    e = await message.edit("😂😂😂😂😂 lawas")
    await asyncio.sleep(1)
    await e.edit("**ʟᴀᴡᴀs ʟᴀᴡᴀs**")
    await e.edit("😂")
    await e.edit("😂😂")
    await e.edit("😂😂😂")
    await e.edit("😂😂😂😂")
    await e.edit("😂😂😂😂😂")
    await e.edit("😂😂😂😂😂😂")
    await e.edit("😂😂😂😂😂😂😂")
@PY.UBOT("bulan")
@PY.TOP_CMD
async def nakall(client, message):
    e = await message.edit("🌗")
    await asyncio.sleep(1)
    await e.edit("🌘")
    await asyncio.sleep(1)
    await e.edit("🌑")
    await asyncio.sleep(1)
    await e.edit("🌒")
    await asyncio.sleep(1)
    await e.edit("🌓")
    await asyncio.sleep(1)
    await e.edit("🌔")
    await asyncio.sleep(1)
    await e.edit("🌕")
    await asyncio.sleep(1)
    await e.edit("🌖")
    await asyncio.sleep(1)
    await e.edit("🌗")
    await asyncio.sleep(1)
    await e.edit("🌘")
    await asyncio.sleep(1)
    await e.edit("🌑")
    await asyncio.sleep(1)
    await e.edit("🌒")
    await asyncio.sleep(1)
    await e.edit("🌓")
    await asyncio.sleep(1)
    await e.edit("🌔")
    await asyncio.sleep(1)
    await e.edit("🌕")
    await asyncio.sleep(1)
    await e.edit("🌖")

@PY.UBOT("kokkelas|kelas")
@PY.TOP_CMD
async def nakall(client, message):
    e = await message.edit("🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("**ʙᴀʙᴜ ᴛᴜᴍʙᴇɴ ᴋᴇʟᴀss**")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥🔥")
    await asyncio.sleep(1)
    await e.edit("🔥")
    await asyncio.sleep(1)
    await e.edit("**ᴋᴇʟᴀs ʙᴀʙᴜᴋᴜ**")
@PY.UBOT("ampas|null")
@PY.TOP_CMD
async def nakall(client, message):
    e = await message.edit("**ɴᴜʟʟ ɴᴜʟʟ ᴀᴍᴘᴀs ʏᴀᴛɪᴍ**")
    await asyncio.sleep(1)
    await e.edit("ɴᴜʟʟʟ")
    await asyncio.sleep(1)
    await e.edit("ɴᴜʟʟ ᴍᴀᴋʟᴜ")
    await asyncio.sleep(1)
    await e.edit("ᴀᴍᴘᴀs YATIM😂")
    await asyncio.sleep(1)
    await e.edit("ᴀᴍᴘᴀs ʟᴀᴡᴀs ɴᴜʟʟ ʟᴀɢɪ 😂")
    await asyncio.sleep(1)
    await e.edit("ᴜᴘᴅᴀᴛᴇ sᴏɴᴏ ғᴜɴᴄᴛɪᴏɴ lu😂")
    await asyncio.sleep(1)
    await e.edit("ɢᴀʙɪsᴀ ᴜᴘᴅᴀᴛᴇ ʏᴇ?ɴʏᴏʟᴏɴɢ 😂😂")
    await asyncio.sleep(1)
    await e.edit("ʙᴀʏ ʙᴀᴘᴀᴋ ᴠᴇɴᴏ ")
@PY.UBOT("yatim")
@PY.TOP_CMD
async def nakall(client, message):
    e = await message.edit("**ᴀᴏᴡᴋᴀᴏᴀᴋᴀ ʏᴀᴛɪᴍ**")
    await asyncio.sleep(1)
    await e.edit("ʙᴀᴘᴀᴋ ᴋᴏ ᴜʙɪ")
    await asyncio.sleep(1)
    await e.edit("ᴀᴏᴡᴋᴡᴏᴀᴋᴀᴏᴀᴋ")
    await asyncio.sleep(1)
    await e.edit("ʙᴇʟɪ ʙᴀᴘᴀᴋ ᴀᴊᴀ ᴅɪ sʜᴏᴘᴇᴇ")
    await asyncio.sleep(1)
    await e.edit("ᴋᴀʟᴏ ʙɪsᴀ ᴅɪ ᴅʀᴀᴋ ᴡᴇʙ ᴀᴊᴀ")
    await asyncio.sleep(1)
    await e.edit("ᴀᴏᴡᴋᴡᴏᴀᴋᴀᴋᴀᴋ")
@PY.UBOT("itam|penghitaman")
@PY.TOP_CMD
async def nakall(client, message):
    e = await message.edit("**ᴘᴇɴɢʜɪᴛᴀᴍᴀɴ sᴇɢᴇʀᴀ ᴅɪ ᴍᴜʟᴀɪ**")
    await asyncio.sleep(1)
    await e.edit("█▒▒▒▒▒▒▒▒▒10%")
    await asyncio.sleep(1)
    await e.edit("████▒▒▒▒▒▒30%")
    await asyncio.sleep(1)
    await e.edit("█████▒▒▒▒▒50%")
    await asyncio.sleep(1)
    await e.edit("████████▒▒80%")
    await asyncio.sleep(1)
    await e.edit("██████████100%")
    await asyncio.sleep(1)
    await e.edit("**ᴘᴇɴɢʜɪᴛᴀᴍᴀɴ sᴇʟᴇsᴀɪ, sɪʟᴀʜᴋᴀɴ ᴄᴇᴋ")
@PY.UBOT("proses|wet cek")
@PY.TOP_CMD
async def nakall(client, message):
    e = await message.edit("**➤; ᴡᴇᴛ ᴋᴜ ᴄᴇᴋ ᴅᴜʟᴜ ᴡᴀᴋ.↶**")
    await asyncio.sleep(3)
    await e.edit("**ᴘʀᴏsᴇs**")
    await asyncio.sleep(2)
    await e.edit("**ᴛᴜɴɢɢᴜ ɴᴏᴛɪғ ᴍᴀsᴜᴋ**")
    await asyncio.sleep(2)
    await e.edit("**ᴍᴀsᴜᴋ ᴡᴀᴋ**")
    await e.edit("**sᴜᴄᴄᴇsғᴜʟʟʏ**")


