import asyncio
import random

from PyroUbot import *

__MODULE__ = "cekkhodam"
__HELP__ = """📖 <u><b>Folder Module Cek Khodam</b></u>

<blockquote><b>📚 perintah: .ᴄᴇᴋᴋʜᴏᴅᴀᴍ [ɴᴀᴍᴀ]</b>
<b>📝 penjelasan: untuk cek khodam dengan nama</b></blockquote>"""


@PY.UBOT("cekkhodam")
@PY.TOP_CMD
async def cekkhodam(client, message):
    try:
        nama = message.text.split(" ", 1)[1] if len(message.text.split()) > 1 else None
        if not nama:
            await message.edit("<b>👉 Gunakan Format:</b>\n<b>.cekkhodam [nama]</b>")
            return

        def pick_random(options):
            return random.choice(options)

        hasil = f"""
 <b>𖤐 ᴄᴇᴋ ᴋʜᴏᴅᴀᴍ:</b>
<blockquote><b>╭───「 ʜᴀsɪʟ ᴄᴇᴋ ᴋʜᴏᴅᴀᴍ 」───</b>
<b>├ •ɴᴀᴍᴀ : {nama}</b>
<b>├ •ᴋʜᴏᴅᴀᴍɴʏᴀ : {pick_random(['lonte gurun', 'dugong', 'macan yatim', 'buaya darat', 'kanjut terbang', 'kuda kayang', 'janda salto', 'lonte alas', 'jembut singa', 'gajah terbang', 'kuda cacat', 'jembut pink', 'sabun bolong'])}</b>
<b>├ •ɴɢᴇʀɪ ʙᴇᴛ ᴊɪʀ ᴋʜᴏᴅᴀᴍɴʏᴀ</b>
<b>╰────────────────────────</b></blockquote>
 <b>ɴᴇxᴛ ᴄᴇᴋ ᴋʜᴏᴅᴀᴍɴʏᴀ sɪᴀᴘᴀ ʟᴀɢɪ.</b>   
      """
        await message.edit(hasil)
    except BaseException:
        pass
