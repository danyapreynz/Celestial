__MODULE__ = "creat"
__HELP__ =  """📖 <u><b>Folder Module Creat</b></u>

<blockquote><b>📚 perintah: .creat [group/channel][tittle]</b>
<b>📝 penjelasan: untuk membuat group dan channel</b></blockquote>"""
