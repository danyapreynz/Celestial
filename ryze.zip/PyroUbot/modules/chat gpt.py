from PyroUbot import *
import random
import requests
from pyrogram.enums import ChatAction, ParseMode
from pyrogram import filters
from pyrogram.types import Message

__MODULE__ = "chatgpt"
__HELP__ =  """📖 <u><b>Folder Module Chatgpt</b></u>

<blockquote><b>📚 perintah: .chatgpt [ᴘᴇʀᴛᴀɴʏᴀᴀɴ]</b>
<b>📝 penjelasan: untuk membuat pertanyaan</b></blockquote>"""


def get_text(message):
    if message.reply_to_message:
        if len(message.text.split()) < 2:
            text = message.reply_to_message.text or message.reply_to_message.caption
        else:
            text = f"{message.reply_to_message.text or message.reply_to_message.caption}\n\n{message.text.split(None, 1)[1]}"
    else:
        if len(message.text.split()) < 2:
            text = ""
        else:
            text = message.text.split(None, 1)[1]
    return text
    
@PY.UBOT("chatgpt")
@PY.TOP_CMD
async def _(client, message):
    try:
        prs = await message.reply_text(f"<b>💬 was running wait a minute. ✨</b>")
        a = get_text(message)
        
        if not a:
            return await prs.edit(f"<b><code>{message.text}</code> [ᴘᴇʀᴛᴀɴʏᴀᴀɴ]</b>")
        
        response = requests.get(f'https://api.botcahx.eu.org/api/search/openai-chat?text={a}&apikey=VENOZY')
        
        try:
            if "message" in response.json():
                x = response.json()["message"]
                await prs.edit(
                    f"{x}\n<blockquote><b>--  --</b></blockquote>"
                )
            else:
                await message.reply_text("no 'results' key found in the response.")
        except KeyError:
            await message.reply_text("error accessing the response.")
    
    except Exception as e:
        await message.reply_text(f"an error occurred: {e}")
