import asyncio
import os
import requests

from bs4 import BeautifulSoup
from io import BytesIO
from PyroUbot import *

__MODULE__ = "carbon"
__HELP__ = """📖 <u><b>Folder Module Carbon</b></u>

<blockquote><b>📚 perintah: .carbon [ᴛᴇxᴛ]<b>
<b>📝 penjelasan: untuk membuat text carbonara</b></blockquote>"""

async def make_carbon(code):
    url = "https://carbonara.solopov.dev/api/cook"
    async with aiosession.post(url, json={"code": code}) as resp:
        image = BytesIO(await resp.read())
    image.name = "carbon.png"
    return image



@PY.UBOT("carbon")
@PY.TOP_CMD
async def carbon_func(client, message):
    text = (
        message.text.split(None, 1)[1]
        if len(
            message.command,
        )
        != 1
        else None
    )
    if message.reply_to_message:
        text = message.reply_to_message.text or message.reply_to_message.caption
    if not text:
        return await message.delete()
    ex = await message.reply("<b>💬 was running wait a minute. ✨</b>")
    carbon = await make_carbon(text)
    await ex.edit("<b>✨uploading...</b>")
    await asyncio.gather(
        ex.delete(),
        client.send_photo(
            message.chat.id,
            carbon,
            caption=f"<b>❄ᴅᴏɴᴇ ᴄᴀʀʙᴏɴɪsᴇᴅ ʙʏ {client.me.mention}</b>",
        ),
    )
    carbon.close()
