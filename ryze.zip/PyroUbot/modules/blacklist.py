__MODULE__ = "blacklist"
__HELP__ =  """📖 <u><b>Folder Module BlackList</b></u>

<blockquote><b>📚 perintah: .addbl</b>
<b>📝 penjelasan: untuk menambahkan group ke dalam daftar blacklist</b></blockquote>
<blockquote><b>📚 perintah: .unbl</b>
<b>📝 penjelasan: untuk menghapus group dari daftar blacklist</b></blockquote>
<blockquote><b>📚 perintah: .rallbl</b>
<b>📝 penjelasan: untuk menghapus semua daftar blacklist group</b></blockquote>
<blockquote><b>📚 perintah: .listbl</b>
<b>📝 penjelasan: untuk memeriksa list blacklist</b></blockquote>"""
