__MODULE__ = "sangmata"
__HELP__ = """📖 <u><b>Folder Module SangMata</b></u>

<blockquote><b>📚 perintah: .sg [ʀᴇᴘʟʏ/ɪᴅ_ᴜsᴇʀ@ᴜsᴇʀɴᴀᴍᴇ]</b>
<b>📝 penjelasan: untuk memeriksa history pengguna</b></blockquote>"""
