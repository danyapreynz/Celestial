from pyrogram import Client, filters
from PyroUbot import PY
from PyroUbot import *

__MODULE__ = "create bot"
__HELP__ = f"""📖 <u><b>Folder Module Create Bot</b></u>>

<blockquote><b>📚 perintah: .createbot [ɴᴀᴍᴀ][ᴜsᴇʀɴᴀᴍᴇ]</b>
<b>📝 penjelasan: untuk membuat bot otomatis dari bot father</b></blockquote>"""


@PY.UBOT("createbot")
@PY.TOP_CMD
async def create_bot_command(client, message):
    # Ambil argumen dari pesan
    args = message.text.split(maxsplit=2)

    if len(args) < 3:
        await message.reply_text(
            "<b>📚 Gunakan Format:</b>\n<b>🌸 .createbot [ɴᴀᴍᴀ][ᴜsᴇʀɴᴀᴍᴇ]</b>"
        )
        return

    bot_name = args[1]
    bot_username = args[2]

    if not bot_username.endswith("bot"):
        await message.reply_text("<b>📛 username harus di akhiri dengan bot‼️</b>")
        return
    try:
        botfather = "@BotFather"
      
        # Kirim perintah ke BotFather
        await client.send_message(botfather, "/newbot")
        await asyncio.sleep(2)
        await client.send_message(botfather, bot_name)
        await asyncio.sleep(2)
        await client.send_message(botfather, bot_username)

        await message.reply_text(
            f"<b>✨ Bot Telah Di Buat Melalui @BotFather</b>\n"
            f"✏️ **Nama Bot: {bot_name}**\n"
            f"🔗 **Username: @{bot_username}**"
        )
    
    except Exception as e:
        await message.reply_text(f"⚠️ Terjadi kesalahan: {str(e)}")