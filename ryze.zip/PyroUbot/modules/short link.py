import requests
from pyrogram import Client, filters
from PyroUbot import *

__MODULE__ = "shortlink"
__HELP__ =  """📖 <u><b>Folder Module ShortLink</b></u>

<blockquote><b>📚 perintah: .shortlink [ʟɪɴᴋ]</b>
<b>📝 penjelasan: untuk mengubah link panjang menjadi pendek</b></blockquote>"""

@PY.UBOT("shortlink")
async def _(client, message):
    if len(message.command) < 2:
        await message.reply_text("<b> ɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ: .shortlink [ʟɪɴᴋ]</b>")
        return
    
    linknyamemek = " ".join(message.command[1:])
    url = f"https://api.botcahx.eu.org/api/linkshort/tinyurl?link={linknyamemek}&apikey=VENOZY"
    
    await message.reply_text("<b>💬 was running wait a minute. ✨</b>")
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if data["status"]:
            await message.reply_text(f"""
<b>__🔗 {linknyamemek} Link Berhasil Di Ubah.__</b>
<b>__🌐 Link: {data['result']}__</b>""")
        else:
            await message.reply_text("eror")
    else:
        await message.reply_text("eror")
