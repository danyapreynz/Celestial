__MODULE__ = "addakses"
__HELP__ = """📖 <u><b>Folder Module Add Akses</b></u>

<blockquote><b>📚 perintah: .prem [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ]</b>
<b>📝 penjelasan: untuk menambahkan user ke dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .unprem [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ]</b>
<b>📝 penjelasan: untuk menghapus prem dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .getprem</b>
<b>📝 penjelasan: untuk melihat jumlah prem dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .seles [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ]</b></b>
<b>📝 penjelasan: untuk menambahkan seles ke dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .unseles [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ]</b>
<b>📝 penjelasan: untuk menghapus seles dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .getseles</b>
<b>📝 penjelasan: untuk melihat jumlah seles dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .admin [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ]</b>
<b>📝 penjelasan: untuk menambahkan admin ke dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .unadmin [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ]</b>
<b>📝 penjelasan: untuk menghapus admin dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .getadmin</b>
<b>📝 penjelasan: untuk melihat jumlah admin dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .addadmbc [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ]</b>
<b>📝 penjelasan: untuk menambahkan admin ke dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .unadmbc [ᴜsᴇʀɴᴀᴍᴇ/ɪᴅ]</b>
<b>📝 penjelasan: untuk menghapus admin dalam db userbot</b></blockquote>
<blockquote><b>📚 perintah: .getadmbc</b>
<b>📝 penjelasan: untuk melihat jumlah admin dalam db userbot</b></blockquote>"""
