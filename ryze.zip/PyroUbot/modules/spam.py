import asyncio

from pyrogram.enums import ChatType
from pyrogram.errors import FloodWait

from .. import *
from PyroUbot import *

__MODULE__ = "spam"
__HELP__ = """📖 <u><b>Folder Module Spam</b></u>

<blockquote><b>📚 perintah: .spam [ʙᴀʟᴇs/ᴛᴇxᴛ][ᴊᴜᴍʟᴀʜ]</b>
<b>📝 penjelasan: untuk melakukan spam pesan</b></blockquote>
<blockquote><b>📚 perintah: .spamgc [ʙᴀʟᴇs/ᴛᴇxᴛ][ᴊᴜᴍʟᴀʜ]</b>
<b>📝 penjelasan: untuk melakukan spam pesan group</b></blockquote>
<blockquote><b>📚 perintah: .setdelay [ᴊᴜᴍʟᴀʜ]</b>
<b>📝 penjelasan: untuk mengatur delay pesan</b></blockquote>
<blockquote><b>📚 perintah: .stopspam</b>
<b>📝 penjelasan: untuk menghentikan spam yang sedang berjalan</b></blockquote>"""

spam_progress = []

async def SpamMsg(client, message, send):
    delay = await get_vars(client.me.id, "SPAM") or 0
    await asyncio.sleep(int(delay))
    if message.reply_to_message:
        await send.copy(message.chat.id)
    else:
        await client.send_message(message.chat.id, send)

@PY.UBOT("spam")
@PY.TOP_CMD
async def _(client, message):
    global spam_progress
    spam_progress.append(client.me.id)
    sks = await EMO.BERHASIL(client)
    _msg = "<b>💬 was running wait a minute. ✨</b>"

    r = await message.reply(_msg)
    count, msg = extract_type_and_msg(message)

    try:
        count = int(count)
    except Exception:
        return await r.edit(f"<b><code>{message.text.split()[0]}</code> [jumlah][text/reply]</b>")

    if not msg:
        return await r.edit(
            f"<b><code>{message.text.split()[0]}</code> [jumlah][text/reply]</b>"
        )
    
    for _ in range(count):
        if client.me.id not in spam_progress:
            await r.edit(f"<b>❗Proses Spam Berhasil Di Batalkan</b>")
            return
        await SpamMsg(client, message, msg)

    spam_progress.remove(client.me.id)    
    await r.edit("<b>✨ Spam Selesai</b>")
@PY.UBOT("spamgc")
@PY.GROUP
async def _(client, message):
    global spam_progress
    spam_progress.append(client.me.id)
    sks = await EMO.BERHASIL(client)
    _msg = "<b>💬 was running wait a minute. ✨</b>"

    r = await message.reply(_msg)
    count, msg = extract_type_and_msg(message)

    try:
        count = int(count)
    except Exception:
        return await r.edit(f"<b><code>{message.text.split()[0]}</code> [jumlah][text/reply]</b>")

    if not msg:
        return await r.edit(
            f"<b><code>{message.text.split()[0]}</code> [jumlah][text/reply]</b>"
        )
    
    for _ in range(count):
        if client.me.id not in spam_progress:
            await r.edit(f"<b>❗Proses Spam Berhasil Di Batalkan</b>")
            return
        await SpamMsg(client, message, msg)

    spam_progress.remove(client.me.id)    
    await r.edit("<b>✨ Spam Selesai</b>")

@PY.UBOT("setdelay")
@PY.TOP_CMD
async def _(client, message):
    _msg = "<b>💬 was running wait a minute. ✨</b>"

    r = await message.reply(_msg)
    count, msg = extract_type_and_msg(message)

    try:
        count = int(count)
    except Exception:
        return await r.edit(f"<b><code>{message.text.split()[0]}</code> [count]</b>")

    if not count:
        return await r.edit(f"<b><code>{message.text.split()[0]}</code> [count]</b>")

    await set_vars(client.me.id, "SPAM", count)
    return await r.edit("<b>spam delay berhasil di setting</b>")

@PY.UBOT("stopspam")
@PY.TOP_CMD
async def _(client, message):
    global spam_progress
    if client.me.id in spam_progress:
        spam_progress.remove(client.me.id)
        await message.reply("<b>spam telah berhenti</b>")
    else:
        await message.reply("<b>tidak ada spam yang ditemukan</b>")
