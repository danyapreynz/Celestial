__MODULE__ = "brad ai"
__HELP__ =  """📖 <u><b>Folder Module Brad Ai</b></u>

<blockquote><b>📚 perintah: .brad</b>
<b>📝 penjelasan: untuk memudahkan membuat cerita, kode komputer, puisi, dll</b></blockquote>"""
