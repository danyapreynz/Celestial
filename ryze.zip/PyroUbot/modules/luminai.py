import random
import requests
from PyroUbot import *

__MODULE__ = "luminai"
__HELP__ = f"""📖 <u><b>Folder Module Lumin Ai</b></u>>

<blockquote><b>📚 perintah: .lumin-ai [ᴘᴇʀᴄᴀᴋᴀᴘᴀɴ]</b>
<b>📝 penjelasan: untuk membuat obrolan dengan lumin ai</b></blockquote>"""

@PY.UBOT("lumin-ai")
async def _(client, message):
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "<b>📚 Gunakan Format:</b>\n<b>🌸 .lumin-ai [percakapan]</b>"
            )
            return

        prs = await message.reply_text("<b>💬 was running wait a minute. ✨</b>")
        query = message.text.split(' ', 1)[1]
        response = requests.get(f'https://api.diioffc.web.id/api/ai/luminai?query={query}')

        try:
            data = response.json()

            if "result" in data and "message" in data["result"]:
                x = data["result"]["message"]
                await prs.edit(f"<b>{x}</b>")
            else:
                await prs.edit("❌ Respons API tidak memiliki data yang diharapkan.")
        except Exception as err:
            await prs.edit(f"⚠️ Terjadi kesalahan saat memproses respons API: {err}")

    except Exception as e:
        await message.reply_text(f"⚠️ Terjadi kesalahan: {e}")
