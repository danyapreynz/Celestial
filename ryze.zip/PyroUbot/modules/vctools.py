__MODULE__ = "vctools"
__HELP__ = """📖 <u><b>Folder Module Vctools</b></u>

<blockquote><b>📚 perintah: .jvc</b>
<b>📝 penjelasan: untuk bergabung ke voice chat group</b></blockquote>
<blockquote><b>📚 perintah: .lvc</b>
<b>📝 penjelasan: untuk meninggalkan voice chat group</b></blockquote>"""

from pyrogram import Client, filters
from pyrogram.types import Message
from asyncio import get_event_loop
from functools import partial
from yt_dlp import YoutubeDL
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream
from pytgcalls.types.calls import Call
from pyrogram.errors import ChatAdminRequired, UserBannedInChannel
from pytgcalls.exceptions import NotInCallError
from youtubesearchpython import VideosSearch
import os
import wget
import math
from datetime import timedelta
from time import time
from pyrogram.errors import FloodWait, MessageNotModified
from youtubesearchpython import VideosSearch
from pyrogram.enums import ChatType
from PyroUbot import *

@PY.UBOT("lvc")
@PY.TOP_CMD
@PY.GROUP
async def leave_vc(client, message):
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    try:
        mex = await message.reply(f"<b>💬 was running wait a minute. ✨</b>")
        await client.call_py.leave_call(message.chat.id)
        await mex.edit(f"{brhsl}berhasil turun dari obrolan suara")
    except NotInCallError:
        await mex.edit(f"{ggl}belum bergabung ke voice chat")
    except UserBannedInChannel:
        pass
    except Exception as e:
        print(e)

@PY.UBOT("jvc")
@PY.TOP_CMD
@PY.GROUP
async def join_vc(client, message):
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    try:
        mex = await message.reply(f"<b>💬 was running wait a minute. ✨</b>")
        await client.call_py.play(message.chat.id)
        await client.call_py.mute_stream(message.chat.id)
        await mex.edit(f"{brhsl}<b>berhasil join ke voice chat</b>")        
    except ChatAdminRequired:
        await mex.edit(f"{ggl}<b>maaf tidak bisa join vc</b>")
    except UserBannedInChannel:
        pass
    except Exception as e:
        print(e)
